# Deploying on Ubuntu VPS

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  YOUR UBUNTU VPS                                             │
│                                                               │
│  ┌──────────┐    ┌──────────────────┐    ┌───────────────┐  │
│  │  Nginx   │───▶│  MCP HTTP Server │───▶│  WordPress    │  │
│  │ :443/SSL │    │  :3100 (local)   │    │  REST API     │  │
│  └──────────┘    └──────────────────┘    │  + WooCommerce│  │
│       ▲                    │              │  + MCP Plugin │  │
│       │                    ▼              └───────────────┘  │
│   Internet          ┌──────────┐                             │
│                     │  MCP     │          (can be same       │
│                     │  stdio   │           server or remote) │
│                     │  server  │                             │
│                     └──────────┘                             │
│                          ▲                                    │
│                          │                                    │
│                    Claude Desktop                             │
│                    / Claude Code                              │
└─────────────────────────────────────────────────────────────┘
```

Two server modes:
- **stdio** — Claude Desktop/Code connects directly (runs locally on VPS)
- **HTTP/SSE** — Remote clients connect via Nginx → port 3100 (for API/remote use)

---

## Quick Deploy

```bash
# 1. Upload files to your VPS
scp -r wordpress-ultimate-mcp/ user@your-vps:/tmp/

# 2. SSH into your VPS
ssh user@your-vps

# 3. Run the deployment script
cd /tmp/wordpress-ultimate-mcp
sudo chmod +x deploy.sh
sudo ./deploy.sh

# 4. Edit credentials
sudo nano /opt/wp-mcp/.env

# 5. Start the server
sudo systemctl enable wp-mcp-http
sudo systemctl start wp-mcp-http

# 6. Verify
curl http://localhost:3100/health

# 7. Install management command
sudo cp wp-mcp /usr/local/bin/
sudo chmod +x /usr/local/bin/wp-mcp

# Now you can use:
sudo wp-mcp status
sudo wp-mcp test
sudo wp-mcp logs
```

---

## Connecting Claude to Your VPS

### Option A: Claude Code via SSH (Recommended)

If you run Claude Code on your local machine and SSH into the VPS:

```bash
# On your local machine, create .mcp.json:
{
  "mcpServers": {
    "wordpress": {
      "command": "ssh",
      "args": ["user@your-vps", "node", "/opt/wp-mcp/server.js"],
      "env": {}
    }
  }
}
```

Claude Code will SSH in and run the MCP server in stdio mode.

### Option B: HTTP Mode (Remote Access)

For connecting Claude (or any MCP client) remotely over HTTPS:

```bash
# 1. Set up Nginx + SSL
sudo nano /etc/nginx/sites-available/wp-mcp  # Set your domain
sudo ln -s /etc/nginx/sites-available/wp-mcp /etc/nginx/sites-enabled/
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d mcp.yourdomain.com
sudo nginx -t && sudo systemctl reload nginx

# 2. Set an API key in .env
sudo nano /opt/wp-mcp/.env
# Add: MCP_API_KEY=your-secret-key-here
sudo systemctl restart wp-mcp-http

# 3. Test from anywhere
curl https://mcp.yourdomain.com/health
```

Then in your MCP client config:
```json
{
  "mcpServers": {
    "wordpress": {
      "url": "https://mcp.yourdomain.com/sse",
      "headers": {
        "Authorization": "Bearer your-secret-key-here"
      }
    }
  }
}
```

### Option C: Direct stdio on VPS

If Claude Code runs directly on the VPS:

```json
{
  "mcpServers": {
    "wordpress": {
      "command": "node",
      "args": ["/opt/wp-mcp/server.js"],
      "env": {
        "WP_URL": "https://yoursite.com",
        "WP_USER": "admin",
        "WP_APP_PASSWORD": "xxxx xxxx xxxx xxxx"
      }
    }
  }
}
```

---

## Management Commands

```bash
sudo wp-mcp status    # Service status + health check
sudo wp-mcp start     # Start server
sudo wp-mcp stop      # Stop server
sudo wp-mcp restart   # Restart server
sudo wp-mcp logs      # View recent logs
sudo wp-mcp health    # Quick health check
sudo wp-mcp test      # Test WordPress connection
sudo wp-mcp update    # Update dependencies
sudo wp-mcp env       # View config (secrets masked)
```

---

## Security Checklist

- [ ] `.env` file has `600` permissions (only `mcp` user can read)
- [ ] Port 3100 is NOT exposed publicly (Nginx proxies it)
- [ ] `MCP_API_KEY` is set in `.env` for HTTP mode
- [ ] SSL certificate is active (via Certbot)
- [ ] UFW firewall is enabled (`sudo ufw status`)
- [ ] WordPress Application Password is for a dedicated user
- [ ] WP-MCP Companion Plugin is only on trusted sites

---

## Monitoring

```bash
# Live logs
sudo journalctl -u wp-mcp-http -f

# Check memory usage
ps aux | grep wp-mcp

# Check open connections
ss -tlnp | grep 3100

# Systemd service health
systemctl is-active wp-mcp-http
```

---

## Updating

```bash
# Upload new files
scp -r sections/ server.js user@your-vps:/opt/wp-mcp/

# Restart
sudo systemctl restart wp-mcp-http

# Or use the management command
sudo wp-mcp update
```
