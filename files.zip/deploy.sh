#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# WordPress Ultimate MCP Server — Ubuntu VPS Deployment Script
# ═══════════════════════════════════════════════════════════════════
#
# Usage:
#   chmod +x deploy.sh
#   sudo ./deploy.sh
#
# This script will:
#   1. Install Node.js 20 LTS
#   2. Create a dedicated 'mcp' system user
#   3. Deploy the MCP server to /opt/wp-mcp
#   4. Set up systemd service with auto-restart
#   5. Configure Nginx reverse proxy (optional)
#   6. Set up UFW firewall rules
#   7. Configure log rotation
#   8. Generate .env file for your credentials
#
# ═══════════════════════════════════════════════════════════════════

set -euo pipefail

# ── Colors ──
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }
info() { echo -e "${CYAN}[i]${NC} $1"; }

# ── Root check ──
if [ "$EUID" -ne 0 ]; then
  err "Please run as root: sudo ./deploy.sh"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  WordPress Ultimate MCP Server — VPS Deployment"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# ═══════════════════════════════════════════════════════════════════
# STEP 1: Install Node.js
# ═══════════════════════════════════════════════════════════════════

info "Step 1: Installing Node.js 20 LTS..."

if command -v node &>/dev/null; then
  NODE_VER=$(node -v)
  log "Node.js already installed: ${NODE_VER}"
else
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
  log "Node.js $(node -v) installed"
fi

# ═══════════════════════════════════════════════════════════════════
# STEP 2: Create system user
# ═══════════════════════════════════════════════════════════════════

info "Step 2: Creating 'mcp' system user..."

if id "mcp" &>/dev/null; then
  log "User 'mcp' already exists"
else
  useradd --system --create-home --home-dir /opt/wp-mcp --shell /usr/sbin/nologin mcp
  log "User 'mcp' created"
fi

# ═══════════════════════════════════════════════════════════════════
# STEP 3: Deploy application
# ═══════════════════════════════════════════════════════════════════

info "Step 3: Deploying MCP server to /opt/wp-mcp..."

APP_DIR="/opt/wp-mcp"
mkdir -p "${APP_DIR}/sections"
mkdir -p "${APP_DIR}/logs"

# Copy files (assumes this script is run from the project directory)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "${SCRIPT_DIR}/server.js" ]; then
  cp "${SCRIPT_DIR}/server.js" "${APP_DIR}/"
  cp "${SCRIPT_DIR}/package.json" "${APP_DIR}/"
  cp "${SCRIPT_DIR}/sections/"*.js "${APP_DIR}/sections/"
  log "Application files copied"
else
  err "server.js not found in ${SCRIPT_DIR}. Run this script from the project directory."
fi

# Install dependencies
cd "${APP_DIR}"
sudo -u mcp npm install --production 2>/dev/null || npm install --production
log "Dependencies installed"

# ═══════════════════════════════════════════════════════════════════
# STEP 4: Create .env file
# ═══════════════════════════════════════════════════════════════════

info "Step 4: Setting up environment variables..."

ENV_FILE="${APP_DIR}/.env"

if [ -f "${ENV_FILE}" ]; then
  warn ".env file already exists — skipping (edit manually if needed)"
else
  cat > "${ENV_FILE}" << 'EOF'
# ═══════════════════════════════════════════════════════════════
# WordPress Ultimate MCP Server — Configuration
# ═══════════════════════════════════════════════════════════════

# REQUIRED: Your WordPress site URL (no trailing slash)
WP_URL=https://yoursite.com

# REQUIRED: WordPress admin username
WP_USER=admin

# REQUIRED: WordPress Application Password
# Create at: wp-admin → Users → Profile → Application Passwords
WP_APP_PASSWORD=xxxx xxxx xxxx xxxx xxxx xxxx

# OPTIONAL: WooCommerce REST API keys
# Create at: WooCommerce → Settings → Advanced → REST API
# WP_WOO_CONSUMER_KEY=ck_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# WP_WOO_CONSUMER_SECRET=cs_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# OPTIONAL: HTTP transport mode for MCP
# stdio = standard (for Claude Desktop/Code — default)
# http  = HTTP server mode (for remote connections)
MCP_TRANSPORT=stdio

# OPTIONAL: HTTP mode settings (only used if MCP_TRANSPORT=http)
MCP_HTTP_PORT=3100
MCP_HTTP_HOST=127.0.0.1

# OPTIONAL: API key for HTTP mode authentication
# MCP_API_KEY=your-secret-key-here
EOF

  chmod 600 "${ENV_FILE}"
  chown mcp:mcp "${ENV_FILE}"
  log ".env file created at ${ENV_FILE}"
  warn "⚠️  EDIT THIS FILE with your real WordPress credentials before starting!"
fi

# ═══════════════════════════════════════════════════════════════════
# STEP 5: Create HTTP transport wrapper (for remote access)
# ═══════════════════════════════════════════════════════════════════

info "Step 5: Creating HTTP transport server..."

cat > "${APP_DIR}/server-http.js" << 'HTTPEOF'
#!/usr/bin/env node
/**
 * HTTP Transport Wrapper for WordPress Ultimate MCP Server
 *
 * This allows remote clients (including Claude via API) to connect
 * to the MCP server over HTTP/SSE instead of stdio.
 *
 * Endpoints:
 *   GET  /sse          — Server-Sent Events stream (MCP messages)
 *   POST /messages     — Send MCP messages
 *   GET  /health       — Health check
 */

import { createServer } from "http";
import { spawn } from "child_process";
import { randomUUID } from "crypto";
import { readFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

// Load .env manually (no dotenv dependency)
function loadEnv() {
  try {
    const envFile = readFileSync(resolve(__dirname, ".env"), "utf8");
    for (const line of envFile.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      const value = trimmed.slice(eqIdx + 1).trim();
      if (!process.env[key]) process.env[key] = value;
    }
  } catch {}
}
loadEnv();

const PORT = parseInt(process.env.MCP_HTTP_PORT || "3100");
const HOST = process.env.MCP_HTTP_HOST || "127.0.0.1";
const API_KEY = process.env.MCP_API_KEY || null;

// ── Auth middleware ──
function checkAuth(req) {
  if (!API_KEY) return true;
  const header = req.headers["authorization"];
  if (header === `Bearer ${API_KEY}`) return true;
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.searchParams.get("api_key") === API_KEY) return true;
  return false;
}

// ── Session management ──
const sessions = new Map();

function createSession() {
  const id = randomUUID();
  const mcpProcess = spawn("node", [resolve(__dirname, "server.js")], {
    env: { ...process.env },
    stdio: ["pipe", "pipe", "pipe"],
  });

  const session = {
    id,
    process: mcpProcess,
    sseClients: new Set(),
    buffer: "",
  };

  // Forward MCP stdout → SSE clients
  mcpProcess.stdout.on("data", (chunk) => {
    session.buffer += chunk.toString();
    const lines = session.buffer.split("\n");
    session.buffer = lines.pop(); // Keep incomplete line in buffer
    for (const line of lines) {
      if (line.trim()) {
        for (const client of session.sseClients) {
          client.write(`data: ${line}\n\n`);
        }
      }
    }
  });

  mcpProcess.stderr.on("data", (data) => {
    console.error(`[session:${id.slice(0, 8)}] ${data.toString().trim()}`);
  });

  mcpProcess.on("close", (code) => {
    console.error(`[session:${id.slice(0, 8)}] MCP process exited (code ${code})`);
    for (const client of session.sseClients) {
      client.write(`event: error\ndata: {"error": "MCP process exited"}\n\n`);
      client.end();
    }
    sessions.delete(id);
  });

  sessions.set(id, session);
  return session;
}

// ── HTTP Server ──
const server = createServer((req, res) => {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host}`);

  // Health check (no auth required)
  if (url.pathname === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({
      status: "ok",
      sessions: sessions.size,
      uptime: process.uptime(),
    }));
    return;
  }

  // Auth check
  if (!checkAuth(req)) {
    res.writeHead(401, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Unauthorized" }));
    return;
  }

  // SSE endpoint — creates a new session
  if (url.pathname === "/sse" && req.method === "GET") {
    const session = createSession();

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });

    // Send session ID and messages endpoint
    res.write(`event: endpoint\ndata: /messages?session_id=${session.id}\n\n`);

    session.sseClients.add(res);

    req.on("close", () => {
      session.sseClients.delete(res);
      if (session.sseClients.size === 0) {
        session.process.kill();
        sessions.delete(session.id);
      }
    });
    return;
  }

  // Messages endpoint — send MCP messages to a session
  if (url.pathname === "/messages" && req.method === "POST") {
    const sessionId = url.searchParams.get("session_id");
    const session = sessions.get(sessionId);

    if (!session) {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Session not found" }));
      return;
    }

    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      try {
        // Write to MCP process stdin
        session.process.stdin.write(body + "\n");
        res.writeHead(202, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ status: "accepted" }));
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // 404
  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(PORT, HOST, () => {
  console.error(`🌐 MCP HTTP Server listening on http://${HOST}:${PORT}`);
  console.error(`   SSE endpoint:     GET  http://${HOST}:${PORT}/sse`);
  console.error(`   Messages:         POST http://${HOST}:${PORT}/messages`);
  console.error(`   Health:           GET  http://${HOST}:${PORT}/health`);
  console.error(`   Auth: ${API_KEY ? "API key required" : "DISABLED (set MCP_API_KEY in .env)"}`);
});
HTTPEOF

chown mcp:mcp "${APP_DIR}/server-http.js"
log "HTTP transport server created"

# ═══════════════════════════════════════════════════════════════════
# STEP 6: Create systemd services
# ═══════════════════════════════════════════════════════════════════

info "Step 6: Creating systemd services..."

# Service for stdio mode (used by Claude Desktop / Claude Code locally)
cat > /etc/systemd/system/wp-mcp.service << EOF
[Unit]
Description=WordPress Ultimate MCP Server (stdio)
After=network.target

[Service]
Type=simple
User=mcp
Group=mcp
WorkingDirectory=/opt/wp-mcp
EnvironmentFile=/opt/wp-mcp/.env
ExecStart=/usr/bin/node /opt/wp-mcp/server.js
Restart=on-failure
RestartSec=5
StartLimitBurst=5
StartLimitIntervalSec=60

# Security hardening
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/opt/wp-mcp/logs
PrivateTmp=yes

# Logging
StandardOutput=append:/opt/wp-mcp/logs/mcp.log
StandardError=append:/opt/wp-mcp/logs/mcp-error.log

[Install]
WantedBy=multi-user.target
EOF

# Service for HTTP mode (used for remote connections)
cat > /etc/systemd/system/wp-mcp-http.service << EOF
[Unit]
Description=WordPress Ultimate MCP Server (HTTP/SSE)
After=network.target

[Service]
Type=simple
User=mcp
Group=mcp
WorkingDirectory=/opt/wp-mcp
EnvironmentFile=/opt/wp-mcp/.env
ExecStart=/usr/bin/node /opt/wp-mcp/server-http.js
Restart=always
RestartSec=5
StartLimitBurst=10
StartLimitIntervalSec=60

# Security hardening
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/opt/wp-mcp/logs
PrivateTmp=yes

# Logging
StandardOutput=append:/opt/wp-mcp/logs/http.log
StandardError=append:/opt/wp-mcp/logs/http-error.log

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
log "Systemd services created"

# ═══════════════════════════════════════════════════════════════════
# STEP 7: Log rotation
# ═══════════════════════════════════════════════════════════════════

info "Step 7: Setting up log rotation..."

cat > /etc/logrotate.d/wp-mcp << EOF
/opt/wp-mcp/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 mcp mcp
    sharedscripts
    postrotate
        systemctl restart wp-mcp-http 2>/dev/null || true
    endscript
}
EOF

log "Log rotation configured (14 days retention)"

# ═══════════════════════════════════════════════════════════════════
# STEP 8: Nginx reverse proxy (optional)
# ═══════════════════════════════════════════════════════════════════

info "Step 8: Nginx configuration..."

if command -v nginx &>/dev/null; then
  cat > /etc/nginx/sites-available/wp-mcp << 'NGINXEOF'
# WordPress Ultimate MCP Server — Nginx Reverse Proxy
#
# Replace YOUR_DOMAIN with your actual domain (e.g., mcp.yoursite.com)
# Then run: sudo ln -s /etc/nginx/sites-available/wp-mcp /etc/nginx/sites-enabled/
#           sudo certbot --nginx -d YOUR_DOMAIN
#           sudo nginx -t && sudo systemctl reload nginx

server {
    listen 80;
    server_name YOUR_DOMAIN;

    # Redirect to HTTPS (uncomment after SSL setup)
    # return 301 https://$host$request_uri;

    location / {
        proxy_pass http://127.0.0.1:3100;
        proxy_http_version 1.1;

        # SSE support
        proxy_set_header Connection '';
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding off;

        # Standard proxy headers
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Timeout for SSE (long-lived connections)
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }

    location /health {
        proxy_pass http://127.0.0.1:3100/health;
        access_log off;
    }
}
NGINXEOF

  log "Nginx config created at /etc/nginx/sites-available/wp-mcp"
  warn "To activate: Edit YOUR_DOMAIN, then symlink and reload nginx"
else
  warn "Nginx not installed — skipping reverse proxy setup"
  info "Install with: apt install nginx"
fi

# ═══════════════════════════════════════════════════════════════════
# STEP 9: Firewall
# ═══════════════════════════════════════════════════════════════════

info "Step 9: Firewall configuration..."

if command -v ufw &>/dev/null; then
  # Only allow MCP port through nginx (port 3100 stays internal)
  ufw allow ssh 2>/dev/null || true
  ufw allow 'Nginx Full' 2>/dev/null || true
  log "UFW rules updated (SSH + Nginx allowed)"
  info "Port 3100 is internal only (not exposed). Nginx proxies external traffic."
else
  warn "UFW not installed — skipping firewall setup"
fi

# ═══════════════════════════════════════════════════════════════════
# STEP 10: Set permissions
# ═══════════════════════════════════════════════════════════════════

info "Step 10: Setting permissions..."

chown -R mcp:mcp "${APP_DIR}"
chmod 750 "${APP_DIR}"
chmod 600 "${APP_DIR}/.env"
chmod 755 "${APP_DIR}/logs"

log "Permissions set"

# ═══════════════════════════════════════════════════════════════════
# DONE
# ═══════════════════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  ✅  DEPLOYMENT COMPLETE"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "  📁 Application:  /opt/wp-mcp/"
echo "  🔑 Credentials:  /opt/wp-mcp/.env"
echo "  📋 Logs:         /opt/wp-mcp/logs/"
echo ""
echo "  NEXT STEPS:"
echo ""
echo "  1. Edit your credentials:"
echo "     ${CYAN}sudo nano /opt/wp-mcp/.env${NC}"
echo ""
echo "  2. Start the HTTP server:"
echo "     ${CYAN}sudo systemctl enable wp-mcp-http${NC}"
echo "     ${CYAN}sudo systemctl start wp-mcp-http${NC}"
echo ""
echo "  3. Check it's running:"
echo "     ${CYAN}curl http://localhost:3100/health${NC}"
echo ""
echo "  4. (Optional) Set up Nginx + SSL for remote access:"
echo "     ${CYAN}sudo nano /etc/nginx/sites-available/wp-mcp${NC}  # Set your domain"
echo "     ${CYAN}sudo ln -s /etc/nginx/sites-available/wp-mcp /etc/nginx/sites-enabled/${NC}"
echo "     ${CYAN}sudo apt install certbot python3-certbot-nginx${NC}"
echo "     ${CYAN}sudo certbot --nginx -d mcp.yoursite.com${NC}"
echo "     ${CYAN}sudo nginx -t && sudo systemctl reload nginx${NC}"
echo ""
echo "  USEFUL COMMANDS:"
echo "     ${CYAN}sudo systemctl status wp-mcp-http${NC}    # Check status"
echo "     ${CYAN}sudo journalctl -u wp-mcp-http -f${NC}    # Live logs"
echo "     ${CYAN}sudo tail -f /opt/wp-mcp/logs/http.log${NC}  # App logs"
echo "     ${CYAN}sudo systemctl restart wp-mcp-http${NC}   # Restart"
echo ""
