/**
 * SECTION 2: Posts & Custom Post Types
 * Full CRUD for posts, custom post types, post meta, revisions
 */

export const postTools = [
  {
    name: "list_posts",
    description: "List blog posts with advanced filtering. Supports status, category, tag, author, date range, search, and custom taxonomy filters.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number", description: "Results per page (max 100)" },
        page: { type: "number", description: "Pagination page number" },
        status: { type: "string", description: "publish, draft, private, pending, trash, any" },
        search: { type: "string", description: "Search keyword" },
        categories: { type: "string", description: "Comma-separated category IDs" },
        tags: { type: "string", description: "Comma-separated tag IDs" },
        author: { type: "number", description: "Filter by author user ID" },
        after: { type: "string", description: "Posts after this ISO 8601 date" },
        before: { type: "string", description: "Posts before this ISO 8601 date" },
        orderby: { type: "string", description: "date, title, slug, modified, id, relevance" },
        order: { type: "string", description: "asc or desc" },
        sticky: { type: "boolean", description: "Filter sticky posts only" },
      },
    },
  },
  {
    name: "get_post",
    description: "Get a single post by ID with full content (rendered + raw), meta fields, categories, tags, featured image, and author info.",
    inputSchema: {
      type: "object",
      properties: {
        post_id: { type: "number", description: "The post ID" },
        context: { type: "string", description: "view or edit" },
      },
      required: ["post_id"],
    },
  },
  {
    name: "create_post",
    description: "Create a new blog post with full options: content, excerpt, categories, tags, featured image, meta, sticky, format, comment/ping status.",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string" },
        content: { type: "string", description: "HTML or block markup" },
        status: { type: "string", description: "draft, publish, private, pending (default: draft)" },
        categories: { type: "array", items: { type: "number" }, description: "Category IDs" },
        tags: { type: "array", items: { type: "number" }, description: "Tag IDs" },
        excerpt: { type: "string" },
        slug: { type: "string" },
        featured_media: { type: "number", description: "Media attachment ID for featured image" },
        format: { type: "string", description: "standard, aside, chat, gallery, link, image, quote, status, video, audio" },
        sticky: { type: "boolean" },
        meta: { type: "object", description: "Custom meta fields" },
        comment_status: { type: "string", description: "open or closed" },
        ping_status: { type: "string", description: "open or closed" },
      },
      required: ["title", "content"],
    },
  },
  {
    name: "update_post",
    description: "Update an existing post. Only provided fields are changed.",
    inputSchema: {
      type: "object",
      properties: {
        post_id: { type: "number" },
        title: { type: "string" },
        content: { type: "string" },
        status: { type: "string" },
        categories: { type: "array", items: { type: "number" } },
        tags: { type: "array", items: { type: "number" } },
        excerpt: { type: "string" },
        slug: { type: "string" },
        featured_media: { type: "number" },
        format: { type: "string" },
        sticky: { type: "boolean" },
        meta: { type: "object" },
      },
      required: ["post_id"],
    },
  },
  {
    name: "delete_post",
    description: "Delete a post (trash or permanent).",
    inputSchema: {
      type: "object",
      properties: {
        post_id: { type: "number" },
        force: { type: "boolean", description: "Permanently delete" },
      },
      required: ["post_id"],
    },
  },
  {
    name: "list_post_revisions",
    description: "Get revision history for a post.",
    inputSchema: {
      type: "object",
      properties: { post_id: { type: "number" } },
      required: ["post_id"],
    },
  },
  {
    name: "bulk_update_posts",
    description: "Bulk update multiple posts (status, category, author, sticky, etc.).",
    inputSchema: {
      type: "object",
      properties: {
        post_ids: { type: "array", items: { type: "number" } },
        status: { type: "string" },
        categories: { type: "array", items: { type: "number" } },
        sticky: { type: "boolean" },
        author: { type: "number" },
      },
      required: ["post_ids"],
    },
  },
  // ── Custom Post Types ──
  {
    name: "list_post_types",
    description: "List all registered post types (built-in and custom). Shows name, slug, rest_base, capabilities, and whether it has an archive.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "list_custom_posts",
    description: "List items of any custom post type (e.g., products, portfolios, testimonials).",
    inputSchema: {
      type: "object",
      properties: {
        post_type: { type: "string", description: "REST base or slug of the custom post type (e.g., 'product', 'portfolio')" },
        per_page: { type: "number" },
        status: { type: "string" },
        search: { type: "string" },
      },
      required: ["post_type"],
    },
  },
  {
    name: "create_custom_post",
    description: "Create an item of any custom post type.",
    inputSchema: {
      type: "object",
      properties: {
        post_type: { type: "string", description: "REST base of the CPT" },
        title: { type: "string" },
        content: { type: "string" },
        status: { type: "string" },
        meta: { type: "object" },
        slug: { type: "string" },
      },
      required: ["post_type", "title"],
    },
  },
  {
    name: "update_custom_post",
    description: "Update a custom post type item by ID.",
    inputSchema: {
      type: "object",
      properties: {
        post_type: { type: "string" },
        post_id: { type: "number" },
        title: { type: "string" },
        content: { type: "string" },
        status: { type: "string" },
        meta: { type: "object" },
      },
      required: ["post_type", "post_id"],
    },
  },
  // ── Categories & Tags ──
  {
    name: "list_categories",
    description: "List categories with count, parent, description.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        search: { type: "string" },
        parent: { type: "number" },
        orderby: { type: "string" },
      },
    },
  },
  {
    name: "create_category",
    description: "Create a new category.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        slug: { type: "string" },
        description: { type: "string" },
        parent: { type: "number" },
      },
      required: ["name"],
    },
  },
  {
    name: "update_category",
    description: "Update a category.",
    inputSchema: {
      type: "object",
      properties: {
        category_id: { type: "number" },
        name: { type: "string" },
        slug: { type: "string" },
        description: { type: "string" },
        parent: { type: "number" },
      },
      required: ["category_id"],
    },
  },
  {
    name: "delete_category",
    description: "Delete a category.",
    inputSchema: {
      type: "object",
      properties: {
        category_id: { type: "number" },
        force: { type: "boolean" },
      },
      required: ["category_id"],
    },
  },
  {
    name: "list_tags",
    description: "List tags.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        search: { type: "string" },
      },
    },
  },
  {
    name: "create_tag",
    description: "Create a new tag.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        slug: { type: "string" },
        description: { type: "string" },
      },
      required: ["name"],
    },
  },
  {
    name: "list_taxonomies",
    description: "List all registered taxonomies (categories, tags, custom taxonomies).",
    inputSchema: { type: "object", properties: {} },
  },
];

export async function handlePostTools(name, args, wpFetch, wpRawFetch) {
  switch (name) {
    case "list_posts": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) {
        if (v !== undefined) params.set(k, String(v));
      }
      const posts = await wpFetch(`/posts?${params}`);
      return posts.map((p) => ({
        id: p.id,
        title: p.title.rendered,
        status: p.status,
        date: p.date,
        link: p.link,
        categories: p.categories,
        tags: p.tags,
        sticky: p.sticky,
        format: p.format,
        author: p.author,
      }));
    }

    case "get_post": {
      const ctx = args.context === "edit" ? "?context=edit" : "";
      const post = await wpFetch(`/posts/${args.post_id}${ctx}`);
      return {
        id: post.id,
        title: post.title.rendered ?? post.title.raw,
        content_rendered: post.content.rendered,
        content_raw: post.content.raw ?? null,
        excerpt: post.excerpt?.rendered ?? post.excerpt?.raw,
        status: post.status,
        date: post.date,
        link: post.link,
        categories: post.categories,
        tags: post.tags,
        sticky: post.sticky,
        format: post.format,
        featured_media: post.featured_media,
        meta: post.meta,
        author: post.author,
      };
    }

    case "create_post": {
      const body = { ...args };
      if (!body.status) body.status = "draft";
      const post = await wpFetch("/posts", { method: "POST", body: JSON.stringify(body) });
      return { id: post.id, title: post.title.rendered, status: post.status, link: post.link, message: `Post created.` };
    }

    case "update_post": {
      const { post_id, ...body } = args;
      const post = await wpFetch(`/posts/${post_id}`, { method: "POST", body: JSON.stringify(body) });
      return { id: post.id, title: post.title.rendered, status: post.status, link: post.link, message: `Post updated.` };
    }

    case "delete_post": {
      const qs = args.force ? "?force=true" : "";
      await wpFetch(`/posts/${args.post_id}${qs}`, { method: "DELETE" });
      return { message: `Post ${args.post_id} deleted.` };
    }

    case "list_post_revisions": {
      const revisions = await wpFetch(`/posts/${args.post_id}/revisions`);
      return revisions.map((r) => ({ id: r.id, date: r.date, author: r.author, title: r.title.rendered }));
    }

    case "bulk_update_posts": {
      const results = [];
      for (const id of args.post_ids) {
        const body = {};
        if (args.status) body.status = args.status;
        if (args.categories) body.categories = args.categories;
        if (args.sticky !== undefined) body.sticky = args.sticky;
        if (args.author) body.author = args.author;
        try {
          await wpFetch(`/posts/${id}`, { method: "POST", body: JSON.stringify(body) });
          results.push({ id, status: "updated" });
        } catch (e) {
          results.push({ id, status: "error", error: e.message });
        }
      }
      return { results };
    }

    case "list_post_types": {
      const types = await wpFetch("/types");
      return Object.values(types).map((t) => ({
        name: t.name,
        slug: t.slug,
        rest_base: t.rest_base,
        description: t.description,
        hierarchical: t.hierarchical,
        has_archive: t.has_archive,
      }));
    }

    case "list_custom_posts": {
      const params = new URLSearchParams();
      if (args.per_page) params.set("per_page", args.per_page);
      if (args.status) params.set("status", args.status);
      if (args.search) params.set("search", args.search);
      const items = await wpFetch(`/${args.post_type}?${params}`);
      return items.map((i) => ({
        id: i.id,
        title: i.title?.rendered,
        status: i.status,
        link: i.link,
        date: i.date,
        meta: i.meta,
      }));
    }

    case "create_custom_post": {
      const { post_type, ...body } = args;
      if (!body.status) body.status = "draft";
      const item = await wpFetch(`/${post_type}`, { method: "POST", body: JSON.stringify(body) });
      return { id: item.id, title: item.title?.rendered, status: item.status, message: `Custom post created.` };
    }

    case "update_custom_post": {
      const { post_type, post_id, ...body } = args;
      const item = await wpFetch(`/${post_type}/${post_id}`, { method: "POST", body: JSON.stringify(body) });
      return { id: item.id, title: item.title?.rendered, status: item.status, message: `Custom post updated.` };
    }

    case "list_categories": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, v);
      const cats = await wpFetch(`/categories?${params}`);
      return cats.map((c) => ({ id: c.id, name: c.name, slug: c.slug, count: c.count, parent: c.parent, description: c.description }));
    }

    case "create_category": {
      const cat = await wpFetch("/categories", { method: "POST", body: JSON.stringify(args) });
      return { id: cat.id, name: cat.name, slug: cat.slug, message: `Category "${cat.name}" created.` };
    }

    case "update_category": {
      const { category_id, ...body } = args;
      const cat = await wpFetch(`/categories/${category_id}`, { method: "POST", body: JSON.stringify(body) });
      return { id: cat.id, name: cat.name, message: `Category updated.` };
    }

    case "delete_category": {
      await wpFetch(`/categories/${args.category_id}?force=true`, { method: "DELETE" });
      return { message: `Category ${args.category_id} deleted.` };
    }

    case "list_tags": {
      const params = new URLSearchParams();
      if (args.per_page) params.set("per_page", args.per_page);
      if (args.search) params.set("search", args.search);
      const tags = await wpFetch(`/tags?${params}`);
      return tags.map((t) => ({ id: t.id, name: t.name, slug: t.slug, count: t.count }));
    }

    case "create_tag": {
      const tag = await wpFetch("/tags", { method: "POST", body: JSON.stringify(args) });
      return { id: tag.id, name: tag.name, slug: tag.slug, message: `Tag "${tag.name}" created.` };
    }

    case "list_taxonomies": {
      const taxonomies = await wpFetch("/taxonomies");
      return Object.values(taxonomies).map((t) => ({
        name: t.name,
        slug: t.slug,
        description: t.description,
        types: t.types,
        hierarchical: t.hierarchical,
      }));
    }

    default:
      return null;
  }
}
