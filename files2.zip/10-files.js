/**
 * SECTION 10: WordPress File Management
 * Browse, read, write, upload, delete, edit files.
 * Manage themes, plugins, uploads, and wp-content files.
 * Also handles media library operations.
 */

export const fileTools = [
  // ── File System ──
  {
    name: "fs_list_directory",
    description: "List files and folders in a directory. Defaults to wp-content. Shows name, type, size, permissions, modified date.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Path relative to WordPress root (e.g., 'wp-content/themes'). Default: 'wp-content'" },
        recursive: { type: "boolean", description: "List subdirectories recursively (default: false)" },
        pattern: { type: "string", description: "Glob pattern filter (e.g., '*.php', '*.css')" },
      },
    },
  },
  {
    name: "fs_read_file",
    description: "Read the contents of a file. Useful for theme/plugin source, config files, .htaccess, wp-config.php.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "File path relative to WP root" },
        encoding: { type: "string", description: "utf8 (default) or base64 for binary" },
        line_start: { type: "number", description: "Read from this line" },
        line_end: { type: "number", description: "Read up to this line" },
      },
      required: ["path"],
    },
  },
  {
    name: "fs_write_file",
    description: "Write content to a file. Creates if doesn't exist. ⚠️ Overwrites unless append mode.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        content: { type: "string" },
        mode: { type: "string", description: "write (default) or append" },
        create_dirs: { type: "boolean", description: "Create parent dirs if needed (default: true)" },
      },
      required: ["path", "content"],
    },
  },
  {
    name: "fs_edit_file",
    description: "Find and replace text within a file. Safer than full overwrite.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        find: { type: "string" },
        replace: { type: "string" },
        regex: { type: "boolean", description: "Treat find as regex (default: false)" },
        all: { type: "boolean", description: "Replace all occurrences (default: false)" },
      },
      required: ["path", "find", "replace"],
    },
  },
  {
    name: "fs_delete_file",
    description: "Delete a file or directory.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        recursive: { type: "boolean", description: "Delete dir + contents (default: false)" },
        confirm: { type: "boolean", description: "Required for recursive deletes" },
      },
      required: ["path"],
    },
  },
  {
    name: "fs_copy_file",
    description: "Copy a file or directory.",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        destination: { type: "string" },
        overwrite: { type: "boolean", description: "Overwrite if exists (default: false)" },
      },
      required: ["source", "destination"],
    },
  },
  {
    name: "fs_move_file",
    description: "Move/rename a file or directory.",
    inputSchema: {
      type: "object",
      properties: {
        source: { type: "string" },
        destination: { type: "string" },
      },
      required: ["source", "destination"],
    },
  },
  {
    name: "fs_create_directory",
    description: "Create a new directory.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        recursive: { type: "boolean", description: "Create parent dirs (default: true)" },
      },
      required: ["path"],
    },
  },
  {
    name: "fs_get_permissions",
    description: "Get file/directory permissions, owner, group.",
    inputSchema: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"],
    },
  },
  {
    name: "fs_set_permissions",
    description: "Set file/directory permissions (chmod).",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        permissions: { type: "string", description: "Octal permissions (e.g., '0755', '0644')" },
        recursive: { type: "boolean" },
      },
      required: ["path", "permissions"],
    },
  },
  {
    name: "fs_search_files",
    description: "Search for files by name pattern or content (grep).",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Starting directory" },
        name_pattern: { type: "string", description: "Filename glob (e.g., '*.php')" },
        content_search: { type: "string", description: "Search inside file contents (grep)" },
        max_depth: { type: "number", description: "Max directory depth (default: 5)" },
      },
      required: ["path"],
    },
  },
  {
    name: "fs_get_disk_usage",
    description: "Get disk usage for a directory or the entire WordPress install.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Directory path (default: WordPress root)" },
      },
    },
  },
  {
    name: "fs_zip_files",
    description: "Create a ZIP archive from files/directories.",
    inputSchema: {
      type: "object",
      properties: {
        paths: { type: "array", items: { type: "string" }, description: "Files/dirs to include" },
        output: { type: "string", description: "Output ZIP path" },
      },
      required: ["paths", "output"],
    },
  },
  {
    name: "fs_unzip",
    description: "Extract a ZIP archive.",
    inputSchema: {
      type: "object",
      properties: {
        zip_path: { type: "string" },
        destination: { type: "string" },
      },
      required: ["zip_path", "destination"],
    },
  },

  // ── Media Library ──
  {
    name: "media_list",
    description: "List media library items with filtering by type, date, search.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        page: { type: "number" },
        media_type: { type: "string", description: "image, video, audio, application" },
        mime_type: { type: "string", description: "Specific MIME type (e.g., image/jpeg)" },
        search: { type: "string" },
        after: { type: "string" },
        before: { type: "string" },
        orderby: { type: "string" },
      },
    },
  },
  {
    name: "media_get",
    description: "Get details of a media item: URL, dimensions, alt text, caption, attached post.",
    inputSchema: {
      type: "object",
      properties: { media_id: { type: "number" } },
      required: ["media_id"],
    },
  },
  {
    name: "media_upload",
    description: "Upload a file to the media library from a URL or base64 data.",
    inputSchema: {
      type: "object",
      properties: {
        source_url: { type: "string", description: "URL to download and upload" },
        base64_data: { type: "string", description: "Base64-encoded file data (alternative to URL)" },
        filename: { type: "string", description: "Filename for the upload" },
        title: { type: "string" },
        alt_text: { type: "string" },
        caption: { type: "string" },
        description: { type: "string" },
      },
    },
  },
  {
    name: "media_update",
    description: "Update media metadata: title, alt text, caption, description.",
    inputSchema: {
      type: "object",
      properties: {
        media_id: { type: "number" },
        title: { type: "string" },
        alt_text: { type: "string" },
        caption: { type: "string" },
        description: { type: "string" },
      },
      required: ["media_id"],
    },
  },
  {
    name: "media_delete",
    description: "Delete a media item.",
    inputSchema: {
      type: "object",
      properties: {
        media_id: { type: "number" },
        force: { type: "boolean" },
      },
      required: ["media_id"],
    },
  },

  // ── Theme File Management ──
  {
    name: "theme_list",
    description: "List installed themes with status, version, screenshot URL.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "theme_get_active",
    description: "Get the active theme details and its template files.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "theme_activate",
    description: "Activate/switch to a different theme.",
    inputSchema: {
      type: "object",
      properties: { theme: { type: "string", description: "Theme stylesheet slug" } },
      required: ["theme"],
    },
  },
  {
    name: "theme_get_file",
    description: "Read a specific theme file (template, functions.php, style.css, etc.).",
    inputSchema: {
      type: "object",
      properties: {
        theme: { type: "string", description: "Theme slug (default: active theme)" },
        file: { type: "string", description: "File path within theme (e.g., 'functions.php', 'templates/page.html')" },
      },
      required: ["file"],
    },
  },
  {
    name: "theme_edit_file",
    description: "Edit a theme file. ⚠️ Use a child theme when possible.",
    inputSchema: {
      type: "object",
      properties: {
        theme: { type: "string" },
        file: { type: "string" },
        content: { type: "string", description: "New file content" },
      },
      required: ["file", "content"],
    },
  },
  {
    name: "theme_create_child",
    description: "Create a child theme from a parent theme. Generates style.css, functions.php, and copies screenshot.",
    inputSchema: {
      type: "object",
      properties: {
        parent_theme: { type: "string", description: "Parent theme slug" },
        child_name: { type: "string", description: "Child theme name" },
        child_slug: { type: "string", description: "Child theme slug/folder name" },
      },
      required: ["parent_theme", "child_name"],
    },
  },
];

export async function handleFileTools(name, args, wpFetch, wpCustomFetch) {
  const base = "/wp-mcp/v1/filesystem";

  switch (name) {
    // ── File System ──
    case "fs_list_directory":
      return await wpCustomFetch(`${base}/list`, { method: "POST", body: JSON.stringify({ path: args.path || "wp-content", recursive: args.recursive, pattern: args.pattern }) });
    case "fs_read_file":
      return await wpCustomFetch(`${base}/read`, { method: "POST", body: JSON.stringify(args) });
    case "fs_write_file":
      return await wpCustomFetch(`${base}/write`, { method: "POST", body: JSON.stringify(args) });
    case "fs_edit_file":
      return await wpCustomFetch(`${base}/edit`, { method: "POST", body: JSON.stringify(args) });
    case "fs_delete_file":
      return await wpCustomFetch(`${base}/delete`, { method: "POST", body: JSON.stringify(args) });
    case "fs_copy_file":
      return await wpCustomFetch(`${base}/copy`, { method: "POST", body: JSON.stringify(args) });
    case "fs_move_file":
      return await wpCustomFetch(`${base}/move`, { method: "POST", body: JSON.stringify(args) });
    case "fs_create_directory":
      return await wpCustomFetch(`${base}/mkdir`, { method: "POST", body: JSON.stringify(args) });
    case "fs_get_permissions":
      return await wpCustomFetch(`${base}/permissions?path=${encodeURIComponent(args.path)}`);
    case "fs_set_permissions":
      return await wpCustomFetch(`${base}/permissions`, { method: "POST", body: JSON.stringify(args) });
    case "fs_search_files":
      return await wpCustomFetch(`${base}/search`, { method: "POST", body: JSON.stringify(args) });
    case "fs_get_disk_usage":
      return await wpCustomFetch(`${base}/disk-usage?path=${encodeURIComponent(args.path || "")}`);
    case "fs_zip_files":
      return await wpCustomFetch(`${base}/zip`, { method: "POST", body: JSON.stringify(args) });
    case "fs_unzip":
      return await wpCustomFetch(`${base}/unzip`, { method: "POST", body: JSON.stringify(args) });

    // ── Media Library ──
    case "media_list": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, String(v));
      const media = await wpFetch(`/media?${params}`);
      return media.map((m) => ({
        id: m.id, title: m.title.rendered, mime_type: m.mime_type,
        source_url: m.source_url, alt_text: m.alt_text,
        media_details: { width: m.media_details?.width, height: m.media_details?.height, file: m.media_details?.file },
        date: m.date,
      }));
    }
    case "media_get": {
      const m = await wpFetch(`/media/${args.media_id}`);
      return {
        id: m.id, title: m.title.rendered, mime_type: m.mime_type,
        source_url: m.source_url, alt_text: m.alt_text, caption: m.caption?.rendered,
        description: m.description?.rendered, media_details: m.media_details, post: m.post,
      };
    }
    case "media_upload":
      return await wpCustomFetch("/wp-mcp/v1/media/upload", { method: "POST", body: JSON.stringify(args) });
    case "media_update": {
      const { media_id, ...body } = args;
      return await wpFetch(`/media/${media_id}`, { method: "POST", body: JSON.stringify(body) });
    }
    case "media_delete":
      return await wpFetch(`/media/${args.media_id}?force=${args.force || true}`, { method: "DELETE" });

    // ── Themes ──
    case "theme_list": {
      const themes = await wpFetch("/themes");
      return themes.map((t) => ({
        stylesheet: t.stylesheet, name: t.name?.rendered || t.name,
        status: t.status, version: t.version, author: t.author?.rendered,
        template: t.template, screenshot: t.screenshot,
      }));
    }
    case "theme_get_active": {
      const themes = await wpFetch("/themes?status=active");
      if (themes.length > 0) {
        const t = themes[0];
        const files = await wpCustomFetch(`/wp-mcp/v1/themes/${t.stylesheet}/files`).catch(() => null);
        return { ...t, files };
      }
      return { error: "No active theme found" };
    }
    case "theme_activate":
      return await wpFetch(`/themes/${args.theme}`, { method: "POST", body: JSON.stringify({ status: "active" }) });
    case "theme_get_file":
      return await wpCustomFetch(`/wp-mcp/v1/themes/${args.theme || "active"}/file?path=${encodeURIComponent(args.file)}`);
    case "theme_edit_file":
      return await wpCustomFetch(`/wp-mcp/v1/themes/${args.theme || "active"}/file`, { method: "POST", body: JSON.stringify({ path: args.file, content: args.content }) });
    case "theme_create_child":
      return await wpCustomFetch("/wp-mcp/v1/themes/create-child", { method: "POST", body: JSON.stringify(args) });

    default:
      return null;
  }
}
