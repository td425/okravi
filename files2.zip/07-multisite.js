/**
 * SECTION 7: WordPress Multisite Management
 * Create, list, update, delete sites in a multisite network.
 * Network-wide user management, plugin/theme activation.
 */

export const multisiteTools = [
  {
    name: "ms_list_sites",
    description: "List all sites in a WordPress multisite network with domain, path, status, and last updated date.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        search: { type: "string" },
        status: { type: "string", description: "public, archived, spam, deleted, mature" },
      },
    },
  },
  {
    name: "ms_get_site",
    description: "Get detailed info about a specific site in the network.",
    inputSchema: {
      type: "object",
      properties: { site_id: { type: "number" } },
      required: ["site_id"],
    },
  },
  {
    name: "ms_create_site",
    description: "Create a new site in the multisite network.",
    inputSchema: {
      type: "object",
      properties: {
        domain: { type: "string", description: "Site domain" },
        path: { type: "string", description: "Site path (e.g., /newsite/)" },
        title: { type: "string", description: "Site title" },
        admin_user_id: { type: "number", description: "Admin user ID for the new site" },
        options: { type: "object", description: "Site options (blogdescription, etc.)" },
      },
      required: ["domain", "title"],
    },
  },
  {
    name: "ms_update_site",
    description: "Update site properties (title, status, domain, path).",
    inputSchema: {
      type: "object",
      properties: {
        site_id: { type: "number" },
        title: { type: "string" },
        domain: { type: "string" },
        path: { type: "string" },
        public: { type: "boolean" },
        archived: { type: "boolean" },
        spam: { type: "boolean" },
        deleted: { type: "boolean" },
        mature: { type: "boolean" },
      },
      required: ["site_id"],
    },
  },
  {
    name: "ms_delete_site",
    description: "Delete a site from the multisite network. ⚠️ Requires confirmation.",
    inputSchema: {
      type: "object",
      properties: {
        site_id: { type: "number" },
        drop_tables: { type: "boolean", description: "Also drop database tables (default: false)" },
        confirm: { type: "boolean" },
      },
      required: ["site_id", "confirm"],
    },
  },
  {
    name: "ms_switch_to_site",
    description: "Set the active site context for subsequent API calls. Useful for managing content on a specific subsite.",
    inputSchema: {
      type: "object",
      properties: {
        site_id: { type: "number", description: "Target site ID to switch to" },
      },
      required: ["site_id"],
    },
  },
  {
    name: "ms_network_activate_plugin",
    description: "Network-activate a plugin across all sites.",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "ms_network_deactivate_plugin",
    description: "Network-deactivate a plugin.",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "ms_network_enable_theme",
    description: "Enable a theme network-wide (makes it available on all sites).",
    inputSchema: {
      type: "object",
      properties: {
        theme: { type: "string", description: "Theme slug" },
      },
      required: ["theme"],
    },
  },
  {
    name: "ms_get_network_settings",
    description: "Get network-wide settings (registration, upload limits, etc.).",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "ms_update_network_settings",
    description: "Update network-wide settings.",
    inputSchema: {
      type: "object",
      properties: {
        registration: { type: "string", description: "none, user, blog, all" },
        upload_space: { type: "number", description: "Upload space per site in MB" },
        fileupload_maxk: { type: "number", description: "Max file upload size in KB" },
        allowed_themes: { type: "object", description: "Themes allowed network-wide" },
      },
    },
  },
];

export async function handleMultisiteTools(name, args, wpCustomFetch) {
  switch (name) {
    case "ms_list_sites":
      return await wpCustomFetch(`/wp-mcp/v1/multisite/sites?${new URLSearchParams(
        Object.fromEntries(Object.entries(args).filter(([, v]) => v !== undefined))
      )}`);
    case "ms_get_site":
      return await wpCustomFetch(`/wp-mcp/v1/multisite/sites/${args.site_id}`);
    case "ms_create_site":
      return await wpCustomFetch("/wp-mcp/v1/multisite/sites", { method: "POST", body: JSON.stringify(args) });
    case "ms_update_site": {
      const { site_id, ...body } = args;
      return await wpCustomFetch(`/wp-mcp/v1/multisite/sites/${site_id}`, { method: "POST", body: JSON.stringify(body) });
    }
    case "ms_delete_site":
      if (!args.confirm) return { error: "Set confirm=true to delete the site." };
      return await wpCustomFetch(`/wp-mcp/v1/multisite/sites/${args.site_id}`, { method: "DELETE", body: JSON.stringify(args) });
    case "ms_switch_to_site":
      return await wpCustomFetch("/wp-mcp/v1/multisite/switch", { method: "POST", body: JSON.stringify({ site_id: args.site_id }) });
    case "ms_network_activate_plugin":
      return await wpCustomFetch("/wp-mcp/v1/multisite/plugins/activate", { method: "POST", body: JSON.stringify(args) });
    case "ms_network_deactivate_plugin":
      return await wpCustomFetch("/wp-mcp/v1/multisite/plugins/deactivate", { method: "POST", body: JSON.stringify(args) });
    case "ms_network_enable_theme":
      return await wpCustomFetch("/wp-mcp/v1/multisite/themes/enable", { method: "POST", body: JSON.stringify(args) });
    case "ms_get_network_settings":
      return await wpCustomFetch("/wp-mcp/v1/multisite/settings");
    case "ms_update_network_settings":
      return await wpCustomFetch("/wp-mcp/v1/multisite/settings", { method: "POST", body: JSON.stringify(args) });
    default:
      return null;
  }
}
