/**
 * SECTION 8: User Management
 * Full user CRUD, roles, capabilities, meta, bulk operations, password resets.
 */

export const userTools = [
  {
    name: "list_users",
    description: "List WordPress users with filtering by role, search, registration date, and ordering.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        page: { type: "number" },
        search: { type: "string" },
        roles: { type: "string", description: "Comma-separated roles: administrator, editor, author, contributor, subscriber, shop_manager, customer" },
        orderby: { type: "string", description: "id, name, email, registered_date, slug" },
        order: { type: "string" },
        who: { type: "string", description: "authors — limit to users who have published posts" },
      },
    },
  },
  {
    name: "get_user",
    description: "Get detailed user profile: roles, capabilities, email, registered date, meta fields, avatar URL.",
    inputSchema: {
      type: "object",
      properties: {
        user_id: { type: "number" },
      },
      required: ["user_id"],
    },
  },
  {
    name: "create_user",
    description: "Create a new WordPress user with username, email, password, roles, and meta.",
    inputSchema: {
      type: "object",
      properties: {
        username: { type: "string" },
        email: { type: "string" },
        password: { type: "string" },
        first_name: { type: "string" },
        last_name: { type: "string" },
        nickname: { type: "string" },
        roles: { type: "array", items: { type: "string" } },
        description: { type: "string", description: "Biographical info" },
        url: { type: "string", description: "User website URL" },
        locale: { type: "string" },
        meta: { type: "object" },
      },
      required: ["username", "email", "password"],
    },
  },
  {
    name: "update_user",
    description: "Update user profile, roles, email, password, or meta.",
    inputSchema: {
      type: "object",
      properties: {
        user_id: { type: "number" },
        email: { type: "string" },
        password: { type: "string" },
        first_name: { type: "string" },
        last_name: { type: "string" },
        nickname: { type: "string" },
        roles: { type: "array", items: { type: "string" } },
        description: { type: "string" },
        url: { type: "string" },
        meta: { type: "object" },
      },
      required: ["user_id"],
    },
  },
  {
    name: "delete_user",
    description: "Delete a user. Optionally reassign their content to another user.",
    inputSchema: {
      type: "object",
      properties: {
        user_id: { type: "number" },
        reassign: { type: "number", description: "User ID to reassign content to" },
        force: { type: "boolean" },
      },
      required: ["user_id"],
    },
  },
  {
    name: "list_roles",
    description: "List all WordPress user roles and their capabilities.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "create_role",
    description: "Create a custom user role with specific capabilities.",
    inputSchema: {
      type: "object",
      properties: {
        role_slug: { type: "string" },
        display_name: { type: "string" },
        capabilities: { type: "object", description: "Capabilities as key:boolean pairs (e.g., {read: true, edit_posts: true})" },
        clone_from: { type: "string", description: "Clone capabilities from existing role before applying overrides" },
      },
      required: ["role_slug", "display_name"],
    },
  },
  {
    name: "update_role_capabilities",
    description: "Add or remove capabilities from an existing role.",
    inputSchema: {
      type: "object",
      properties: {
        role: { type: "string", description: "Role slug" },
        add_capabilities: { type: "array", items: { type: "string" } },
        remove_capabilities: { type: "array", items: { type: "string" } },
      },
      required: ["role"],
    },
  },
  {
    name: "delete_role",
    description: "Delete a custom user role.",
    inputSchema: {
      type: "object",
      properties: {
        role: { type: "string" },
        migrate_to: { type: "string", description: "Role to migrate users to before deletion" },
      },
      required: ["role"],
    },
  },
  {
    name: "bulk_update_users",
    description: "Bulk update users: change role, status, or meta for multiple users.",
    inputSchema: {
      type: "object",
      properties: {
        user_ids: { type: "array", items: { type: "number" } },
        roles: { type: "array", items: { type: "string" } },
        meta: { type: "object" },
      },
      required: ["user_ids"],
    },
  },
  {
    name: "get_current_user",
    description: "Get the currently authenticated user's profile.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "get_user_meta",
    description: "Get all meta fields for a user.",
    inputSchema: {
      type: "object",
      properties: { user_id: { type: "number" } },
      required: ["user_id"],
    },
  },
  {
    name: "update_user_meta",
    description: "Set a user meta field.",
    inputSchema: {
      type: "object",
      properties: {
        user_id: { type: "number" },
        meta_key: { type: "string" },
        meta_value: { type: "string" },
      },
      required: ["user_id", "meta_key", "meta_value"],
    },
  },
];

export async function handleUserTools(name, args, wpFetch, wpCustomFetch) {
  switch (name) {
    case "list_users": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, String(v));
      const users = await wpFetch(`/users?${params}`);
      return users.map((u) => ({
        id: u.id, name: u.name, slug: u.slug, email: u.email,
        roles: u.roles, registered_date: u.registered_date,
        avatar_urls: u.avatar_urls,
      }));
    }
    case "get_user": {
      const u = await wpFetch(`/users/${args.user_id}?context=edit`);
      return { id: u.id, username: u.username, name: u.name, email: u.email, roles: u.roles, capabilities: u.capabilities, registered_date: u.registered_date, meta: u.meta, description: u.description, url: u.url, locale: u.locale };
    }
    case "create_user":
      return await wpFetch("/users", { method: "POST", body: JSON.stringify(args) });
    case "update_user": {
      const { user_id, ...body } = args;
      return await wpFetch(`/users/${user_id}`, { method: "POST", body: JSON.stringify(body) });
    }
    case "delete_user": {
      const params = new URLSearchParams();
      if (args.reassign) params.set("reassign", args.reassign);
      params.set("force", "true");
      return await wpFetch(`/users/${args.user_id}?${params}`, { method: "DELETE" });
    }
    case "list_roles":
      return await wpCustomFetch("/wp-mcp/v1/users/roles");
    case "create_role":
      return await wpCustomFetch("/wp-mcp/v1/users/roles", { method: "POST", body: JSON.stringify(args) });
    case "update_role_capabilities":
      return await wpCustomFetch(`/wp-mcp/v1/users/roles/${args.role}/capabilities`, { method: "POST", body: JSON.stringify(args) });
    case "delete_role":
      return await wpCustomFetch(`/wp-mcp/v1/users/roles/${args.role}`, { method: "DELETE", body: JSON.stringify(args) });
    case "bulk_update_users": {
      const results = [];
      for (const id of args.user_ids) {
        const body = {};
        if (args.roles) body.roles = args.roles;
        if (args.meta) body.meta = args.meta;
        try {
          await wpFetch(`/users/${id}`, { method: "POST", body: JSON.stringify(body) });
          results.push({ id, status: "updated" });
        } catch (e) {
          results.push({ id, status: "error", error: e.message });
        }
      }
      return { results };
    }
    case "get_current_user":
      return await wpFetch("/users/me?context=edit");
    case "get_user_meta":
      return await wpCustomFetch(`/wp-mcp/v1/users/${args.user_id}/meta`);
    case "update_user_meta":
      return await wpCustomFetch(`/wp-mcp/v1/users/${args.user_id}/meta`, { method: "POST", body: JSON.stringify({ key: args.meta_key, value: args.meta_value }) });
    default:
      return null;
  }
}
