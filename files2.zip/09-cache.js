/**
 * SECTION 9: Caching Control
 * Manage WordPress object cache, page cache, transients, opcache,
 * and popular caching plugin integrations (WP Super Cache, W3TC, LiteSpeed, WP Rocket).
 */

export const cacheTools = [
  {
    name: "cache_flush_all",
    description: "Flush ALL caches: object cache, page cache, transients, opcache. Nuclear option.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cache_flush_object",
    description: "Flush the WordPress object cache (wp_cache_flush).",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cache_flush_page",
    description: "Flush the page/HTML cache. Works with WP Super Cache, W3TC, LiteSpeed Cache, WP Rocket, etc.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cache_flush_url",
    description: "Purge cache for a specific URL or path.",
    inputSchema: {
      type: "object",
      properties: {
        url: { type: "string", description: "Full URL or path to purge" },
      },
      required: ["url"],
    },
  },
  {
    name: "cache_flush_post",
    description: "Purge all caches related to a specific post/page ID.",
    inputSchema: {
      type: "object",
      properties: {
        post_id: { type: "number" },
      },
      required: ["post_id"],
    },
  },
  {
    name: "cache_flush_transients",
    description: "Delete expired or all transients from the database.",
    inputSchema: {
      type: "object",
      properties: {
        expired_only: { type: "boolean", description: "Only delete expired transients (default: true)" },
      },
    },
  },
  {
    name: "cache_flush_opcache",
    description: "Reset PHP OPcache.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cache_get_status",
    description: "Get caching status: which cache layers are active, object cache backend, page cache plugin, opcache stats.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "cache_preload",
    description: "Trigger cache preloading/warming for the site. Crawls key URLs to populate cache.",
    inputSchema: {
      type: "object",
      properties: {
        urls: { type: "array", items: { type: "string" }, description: "Specific URLs to preload (optional — defaults to sitemap)" },
      },
    },
  },
  {
    name: "cache_get_transient",
    description: "Get the value of a specific transient.",
    inputSchema: {
      type: "object",
      properties: { name: { type: "string" } },
      required: ["name"],
    },
  },
  {
    name: "cache_set_transient",
    description: "Set a transient with a value and expiration.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        value: { type: "string" },
        expiration: { type: "number", description: "Seconds until expiry (0 = no expiry)" },
      },
      required: ["name", "value"],
    },
  },
  {
    name: "cache_delete_transient",
    description: "Delete a specific transient.",
    inputSchema: {
      type: "object",
      properties: { name: { type: "string" } },
      required: ["name"],
    },
  },
];

export async function handleCacheTools(name, args, wpCustomFetch) {
  const base = "/wp-mcp/v1/cache";
  switch (name) {
    case "cache_flush_all":
      return await wpCustomFetch(`${base}/flush-all`, { method: "POST" });
    case "cache_flush_object":
      return await wpCustomFetch(`${base}/flush-object`, { method: "POST" });
    case "cache_flush_page":
      return await wpCustomFetch(`${base}/flush-page`, { method: "POST" });
    case "cache_flush_url":
      return await wpCustomFetch(`${base}/flush-url`, { method: "POST", body: JSON.stringify(args) });
    case "cache_flush_post":
      return await wpCustomFetch(`${base}/flush-post`, { method: "POST", body: JSON.stringify(args) });
    case "cache_flush_transients":
      return await wpCustomFetch(`${base}/flush-transients`, { method: "POST", body: JSON.stringify({ expired_only: args.expired_only !== false }) });
    case "cache_flush_opcache":
      return await wpCustomFetch(`${base}/flush-opcache`, { method: "POST" });
    case "cache_get_status":
      return await wpCustomFetch(`${base}/status`);
    case "cache_preload":
      return await wpCustomFetch(`${base}/preload`, { method: "POST", body: JSON.stringify(args) });
    case "cache_get_transient":
      return await wpCustomFetch(`${base}/transients/${encodeURIComponent(args.name)}`);
    case "cache_set_transient":
      return await wpCustomFetch(`${base}/transients`, { method: "POST", body: JSON.stringify(args) });
    case "cache_delete_transient":
      return await wpCustomFetch(`${base}/transients/${encodeURIComponent(args.name)}`, { method: "DELETE" });
    default:
      return null;
  }
}
