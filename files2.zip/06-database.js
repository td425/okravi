/**
 * SECTION 6: Database Access & Control
 * Direct database access via WP-MCP companion plugin.
 * Execute SQL queries, manage tables, create custom tables,
 * import/export data, view table structures.
 *
 * ⚠️ DANGEROUS — These tools execute raw SQL. The companion plugin
 * should enforce role checks and query allowlists in production.
 */

export const dbTools = [
  {
    name: "db_query",
    description: "Execute a read-only SQL query (SELECT) against the WordPress database. Returns results as JSON. The query automatically uses the WordPress table prefix ($prefix).",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string", description: "SQL SELECT query. Use {prefix} as table prefix placeholder (e.g., 'SELECT * FROM {prefix}posts LIMIT 10')" },
        params: { type: "array", items: { type: "string" }, description: "Parameterized values for prepared statements (use %s, %d, %f placeholders)" },
      },
      required: ["query"],
    },
  },
  {
    name: "db_execute",
    description: "Execute a write SQL query (INSERT, UPDATE, DELETE, ALTER, CREATE). Returns affected rows count. ⚠️ Use with caution — changes are immediate and not easily reversible.",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string", description: "SQL write query. Use {prefix} for table prefix." },
        params: { type: "array", items: { type: "string" }, description: "Parameterized values" },
      },
      required: ["query"],
    },
  },
  {
    name: "db_list_tables",
    description: "List all tables in the WordPress database with row counts and sizes.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "db_describe_table",
    description: "Get the structure (columns, types, keys, defaults) of a database table.",
    inputSchema: {
      type: "object",
      properties: {
        table: { type: "string", description: "Table name (with or without prefix). If no prefix given, WP prefix is auto-added." },
      },
      required: ["table"],
    },
  },
  {
    name: "db_create_table",
    description: "Create a custom database table. Provide column definitions, indexes, and engine type. Uses WordPress dbDelta() for safe creation.",
    inputSchema: {
      type: "object",
      properties: {
        table_name: { type: "string", description: "Table name without prefix (prefix is auto-added)" },
        columns: {
          type: "array",
          description: "Column definitions",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              type: { type: "string", description: "MySQL type: INT, BIGINT, VARCHAR(255), TEXT, LONGTEXT, DATETIME, DECIMAL(10,2), etc." },
              nullable: { type: "boolean", description: "Allow NULL (default: false)" },
              default: { type: "string", description: "Default value" },
              auto_increment: { type: "boolean" },
              primary_key: { type: "boolean" },
            },
            required: ["name", "type"],
          },
        },
        indexes: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              columns: { type: "array", items: { type: "string" } },
              unique: { type: "boolean" },
            },
          },
        },
        engine: { type: "string", description: "InnoDB (default) or MyISAM" },
        charset: { type: "string", description: "Default: utf8mb4" },
      },
      required: ["table_name", "columns"],
    },
  },
  {
    name: "db_drop_table",
    description: "Drop (delete) a database table. ⚠️ IRREVERSIBLE. Requires confirmation parameter.",
    inputSchema: {
      type: "object",
      properties: {
        table_name: { type: "string", description: "Full table name or name without prefix" },
        confirm: { type: "boolean", description: "Must be true to execute" },
      },
      required: ["table_name", "confirm"],
    },
  },
  {
    name: "db_alter_table",
    description: "Alter a table: add/drop/modify columns, add/drop indexes.",
    inputSchema: {
      type: "object",
      properties: {
        table_name: { type: "string" },
        add_columns: { type: "array", items: { type: "object", properties: { name: { type: "string" }, type: { type: "string" }, after: { type: "string" } } } },
        drop_columns: { type: "array", items: { type: "string" } },
        modify_columns: { type: "array", items: { type: "object", properties: { name: { type: "string" }, type: { type: "string" }, nullable: { type: "boolean" } } } },
        add_indexes: { type: "array", items: { type: "object", properties: { name: { type: "string" }, columns: { type: "array", items: { type: "string" } }, unique: { type: "boolean" } } } },
        drop_indexes: { type: "array", items: { type: "string" } },
      },
      required: ["table_name"],
    },
  },
  {
    name: "db_export_table",
    description: "Export a table's data as JSON or CSV.",
    inputSchema: {
      type: "object",
      properties: {
        table_name: { type: "string" },
        format: { type: "string", description: "json or csv (default: json)" },
        where: { type: "string", description: "Optional WHERE clause (without WHERE keyword)" },
        limit: { type: "number", description: "Max rows (default: 1000)" },
      },
      required: ["table_name"],
    },
  },
  {
    name: "db_import_data",
    description: "Import data into a table from JSON array.",
    inputSchema: {
      type: "object",
      properties: {
        table_name: { type: "string" },
        data: { type: "array", items: { type: "object" }, description: "Array of row objects (keys = column names)" },
        mode: { type: "string", description: "insert (default), replace, or ignore" },
      },
      required: ["table_name", "data"],
    },
  },
  {
    name: "db_get_table_prefix",
    description: "Get the WordPress table prefix (e.g., wp_).",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "db_get_option",
    description: "Get a WordPress option from the options table.",
    inputSchema: {
      type: "object",
      properties: {
        option_name: { type: "string" },
      },
      required: ["option_name"],
    },
  },
  {
    name: "db_update_option",
    description: "Update or create a WordPress option.",
    inputSchema: {
      type: "object",
      properties: {
        option_name: { type: "string" },
        option_value: { type: "string", description: "Value (will be serialized if needed)" },
        autoload: { type: "string", description: "yes or no (default: yes)" },
      },
      required: ["option_name", "option_value"],
    },
  },
  {
    name: "db_search_replace",
    description: "Search and replace across database tables (serialization-safe). Useful for domain migrations.",
    inputSchema: {
      type: "object",
      properties: {
        search: { type: "string", description: "String to find" },
        replace: { type: "string", description: "Replacement string" },
        tables: { type: "array", items: { type: "string" }, description: "Tables to process (default: all WP tables)" },
        dry_run: { type: "boolean", description: "Preview changes without applying (default: true)" },
      },
      required: ["search", "replace"],
    },
  },
];

export async function handleDbTools(name, args, wpCustomFetch) {
  switch (name) {
    case "db_query":
      return await wpCustomFetch("/wp-mcp/v1/db/query", {
        method: "POST",
        body: JSON.stringify({ query: args.query, params: args.params, type: "select" }),
      });

    case "db_execute":
      return await wpCustomFetch("/wp-mcp/v1/db/query", {
        method: "POST",
        body: JSON.stringify({ query: args.query, params: args.params, type: "execute" }),
      });

    case "db_list_tables":
      return await wpCustomFetch("/wp-mcp/v1/db/tables");

    case "db_describe_table":
      return await wpCustomFetch(`/wp-mcp/v1/db/tables/${encodeURIComponent(args.table)}/describe`);

    case "db_create_table":
      return await wpCustomFetch("/wp-mcp/v1/db/tables/create", {
        method: "POST",
        body: JSON.stringify(args),
      });

    case "db_drop_table":
      if (!args.confirm) return { error: "Set confirm=true to drop the table. This is irreversible." };
      return await wpCustomFetch(`/wp-mcp/v1/db/tables/${encodeURIComponent(args.table_name)}`, {
        method: "DELETE",
        body: JSON.stringify({ confirm: true }),
      });

    case "db_alter_table":
      return await wpCustomFetch(`/wp-mcp/v1/db/tables/${encodeURIComponent(args.table_name)}/alter`, {
        method: "POST",
        body: JSON.stringify(args),
      });

    case "db_export_table":
      return await wpCustomFetch(`/wp-mcp/v1/db/tables/${encodeURIComponent(args.table_name)}/export`, {
        method: "POST",
        body: JSON.stringify({ format: args.format || "json", where: args.where, limit: args.limit || 1000 }),
      });

    case "db_import_data":
      return await wpCustomFetch(`/wp-mcp/v1/db/tables/${encodeURIComponent(args.table_name)}/import`, {
        method: "POST",
        body: JSON.stringify({ data: args.data, mode: args.mode || "insert" }),
      });

    case "db_get_table_prefix":
      return await wpCustomFetch("/wp-mcp/v1/db/prefix");

    case "db_get_option":
      return await wpCustomFetch(`/wp-mcp/v1/db/options/${encodeURIComponent(args.option_name)}`);

    case "db_update_option":
      return await wpCustomFetch("/wp-mcp/v1/db/options", {
        method: "POST",
        body: JSON.stringify(args),
      });

    case "db_search_replace":
      return await wpCustomFetch("/wp-mcp/v1/db/search-replace", {
        method: "POST",
        body: JSON.stringify(args),
      });

    default:
      return null;
  }
}
