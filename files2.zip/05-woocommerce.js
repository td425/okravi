/**
 * SECTION 5: WooCommerce Integration
 * Full WooCommerce management: products, variations, orders, cart, coupons,
 * customers, shipping, tax, reports, settings.
 * Uses WooCommerce REST API v3 (wc/v3).
 */

export const wooTools = [
  // ── Products ──
  {
    name: "woo_list_products",
    description: "List WooCommerce products with filtering by status, category, tag, type, stock status, price range, featured, on_sale.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        page: { type: "number" },
        status: { type: "string", description: "publish, draft, pending, private, trash" },
        search: { type: "string" },
        category: { type: "string", description: "Category ID" },
        tag: { type: "string", description: "Tag ID" },
        type: { type: "string", description: "simple, grouped, external, variable" },
        stock_status: { type: "string", description: "instock, outofstock, onbackorder" },
        featured: { type: "boolean" },
        on_sale: { type: "boolean" },
        min_price: { type: "string" },
        max_price: { type: "string" },
        orderby: { type: "string", description: "date, id, title, slug, price, popularity, rating" },
        order: { type: "string" },
        sku: { type: "string" },
      },
    },
  },
  {
    name: "woo_get_product",
    description: "Get a single product with full details: pricing, stock, attributes, variations, images, meta, cross-sells, upsells.",
    inputSchema: {
      type: "object",
      properties: { product_id: { type: "number" } },
      required: ["product_id"],
    },
  },
  {
    name: "woo_create_product",
    description: "Create a WooCommerce product (simple, variable, grouped, external). Full support for pricing, stock, attributes, images, categories, tags, cross-sells, upsells, meta.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        type: { type: "string", description: "simple, variable, grouped, external (default: simple)" },
        status: { type: "string", description: "publish, draft, pending (default: draft)" },
        description: { type: "string", description: "Full HTML description" },
        short_description: { type: "string" },
        sku: { type: "string" },
        regular_price: { type: "string" },
        sale_price: { type: "string" },
        manage_stock: { type: "boolean" },
        stock_quantity: { type: "number" },
        stock_status: { type: "string" },
        weight: { type: "string" },
        dimensions: { type: "object", properties: { length: { type: "string" }, width: { type: "string" }, height: { type: "string" } } },
        categories: { type: "array", items: { type: "object", properties: { id: { type: "number" } } } },
        tags: { type: "array", items: { type: "object", properties: { id: { type: "number" } } } },
        images: { type: "array", items: { type: "object", properties: { src: { type: "string" }, alt: { type: "string" } } } },
        attributes: { type: "array", items: { type: "object", properties: { name: { type: "string" }, options: { type: "array", items: { type: "string" } }, variation: { type: "boolean" }, visible: { type: "boolean" } } } },
        virtual: { type: "boolean" },
        downloadable: { type: "boolean" },
        featured: { type: "boolean" },
        catalog_visibility: { type: "string", description: "visible, catalog, search, hidden" },
        tax_status: { type: "string" },
        tax_class: { type: "string" },
        cross_sell_ids: { type: "array", items: { type: "number" } },
        upsell_ids: { type: "array", items: { type: "number" } },
        meta_data: { type: "array", items: { type: "object", properties: { key: { type: "string" }, value: { type: "string" } } } },
      },
      required: ["name"],
    },
  },
  {
    name: "woo_update_product",
    description: "Update any field of an existing product.",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        name: { type: "string" },
        status: { type: "string" },
        description: { type: "string" },
        short_description: { type: "string" },
        sku: { type: "string" },
        regular_price: { type: "string" },
        sale_price: { type: "string" },
        manage_stock: { type: "boolean" },
        stock_quantity: { type: "number" },
        stock_status: { type: "string" },
        categories: { type: "array", items: { type: "object" } },
        images: { type: "array", items: { type: "object" } },
        attributes: { type: "array", items: { type: "object" } },
        meta_data: { type: "array", items: { type: "object" } },
        featured: { type: "boolean" },
        cross_sell_ids: { type: "array", items: { type: "number" } },
        upsell_ids: { type: "array", items: { type: "number" } },
      },
      required: ["product_id"],
    },
  },
  {
    name: "woo_delete_product",
    description: "Delete a product.",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        force: { type: "boolean" },
      },
      required: ["product_id"],
    },
  },
  {
    name: "woo_bulk_update_products",
    description: "Batch create, update, or delete multiple products in one request.",
    inputSchema: {
      type: "object",
      properties: {
        create: { type: "array", items: { type: "object" }, description: "Products to create" },
        update: { type: "array", items: { type: "object" }, description: "Products to update (must include id)" },
        delete: { type: "array", items: { type: "number" }, description: "Product IDs to delete" },
      },
    },
  },

  // ── Product Variations ──
  {
    name: "woo_list_variations",
    description: "List variations for a variable product.",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        per_page: { type: "number" },
      },
      required: ["product_id"],
    },
  },
  {
    name: "woo_create_variation",
    description: "Create a product variation (for variable products).",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        regular_price: { type: "string" },
        sale_price: { type: "string" },
        sku: { type: "string" },
        stock_quantity: { type: "number" },
        manage_stock: { type: "boolean" },
        attributes: { type: "array", items: { type: "object", properties: { name: { type: "string" }, option: { type: "string" } } } },
        image: { type: "object", properties: { src: { type: "string" } } },
        weight: { type: "string" },
        dimensions: { type: "object" },
      },
      required: ["product_id", "attributes"],
    },
  },
  {
    name: "woo_update_variation",
    description: "Update a product variation.",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        variation_id: { type: "number" },
        regular_price: { type: "string" },
        sale_price: { type: "string" },
        sku: { type: "string" },
        stock_quantity: { type: "number" },
        manage_stock: { type: "boolean" },
        attributes: { type: "array", items: { type: "object" } },
        image: { type: "object" },
      },
      required: ["product_id", "variation_id"],
    },
  },

  // ── Product Categories ──
  {
    name: "woo_list_product_categories",
    description: "List WooCommerce product categories.",
    inputSchema: {
      type: "object",
      properties: { per_page: { type: "number" }, search: { type: "string" }, parent: { type: "number" } },
    },
  },
  {
    name: "woo_create_product_category",
    description: "Create a product category.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string" },
        slug: { type: "string" },
        parent: { type: "number" },
        description: { type: "string" },
        image: { type: "object", properties: { src: { type: "string" } } },
      },
      required: ["name"],
    },
  },

  // ── Orders ──
  {
    name: "woo_list_orders",
    description: "List orders with filtering by status, customer, date range, product.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        page: { type: "number" },
        status: { type: "string", description: "pending, processing, on-hold, completed, cancelled, refunded, failed, trash, any" },
        customer: { type: "number", description: "Customer user ID" },
        after: { type: "string", description: "Orders after ISO 8601 date" },
        before: { type: "string", description: "Orders before ISO 8601 date" },
        search: { type: "string" },
        product: { type: "number", description: "Filter by product ID" },
        orderby: { type: "string" },
        order: { type: "string" },
      },
    },
  },
  {
    name: "woo_get_order",
    description: "Get full order details: line items, billing, shipping, totals, payment method, notes, refunds.",
    inputSchema: {
      type: "object",
      properties: { order_id: { type: "number" } },
      required: ["order_id"],
    },
  },
  {
    name: "woo_create_order",
    description: "Create a new order programmatically with line items, billing/shipping addresses, payment method.",
    inputSchema: {
      type: "object",
      properties: {
        status: { type: "string" },
        customer_id: { type: "number" },
        billing: { type: "object" },
        shipping: { type: "object" },
        line_items: { type: "array", items: { type: "object", properties: { product_id: { type: "number" }, quantity: { type: "number" }, variation_id: { type: "number" } } } },
        shipping_lines: { type: "array", items: { type: "object" } },
        coupon_lines: { type: "array", items: { type: "object", properties: { code: { type: "string" } } } },
        fee_lines: { type: "array", items: { type: "object" } },
        payment_method: { type: "string" },
        payment_method_title: { type: "string" },
        set_paid: { type: "boolean" },
        meta_data: { type: "array", items: { type: "object" } },
      },
      required: ["line_items"],
    },
  },
  {
    name: "woo_update_order",
    description: "Update order status, line items, addresses, notes, or meta.",
    inputSchema: {
      type: "object",
      properties: {
        order_id: { type: "number" },
        status: { type: "string" },
        billing: { type: "object" },
        shipping: { type: "object" },
        meta_data: { type: "array", items: { type: "object" } },
      },
      required: ["order_id"],
    },
  },
  {
    name: "woo_add_order_note",
    description: "Add a note to an order (visible to customer or internal).",
    inputSchema: {
      type: "object",
      properties: {
        order_id: { type: "number" },
        note: { type: "string" },
        customer_note: { type: "boolean", description: "true = visible to customer, false = private (default: false)" },
      },
      required: ["order_id", "note"],
    },
  },
  {
    name: "woo_create_refund",
    description: "Create a refund for an order.",
    inputSchema: {
      type: "object",
      properties: {
        order_id: { type: "number" },
        amount: { type: "string", description: "Refund amount" },
        reason: { type: "string" },
        line_items: { type: "array", items: { type: "object" }, description: "Specific line items to refund" },
      },
      required: ["order_id", "amount"],
    },
  },

  // ── Cart (via custom endpoint) ──
  {
    name: "woo_get_cart",
    description: "Get the current cart contents for a session/customer. Returns items, totals, coupons applied.",
    inputSchema: {
      type: "object",
      properties: {
        cart_key: { type: "string", description: "Cart session key (for headless/API carts)" },
      },
    },
  },
  {
    name: "woo_add_to_cart",
    description: "Add a product to the cart.",
    inputSchema: {
      type: "object",
      properties: {
        product_id: { type: "number" },
        quantity: { type: "number", description: "Default 1" },
        variation_id: { type: "number" },
        variation: { type: "object", description: "Variation attributes as key-value pairs" },
        cart_key: { type: "string" },
      },
      required: ["product_id"],
    },
  },
  {
    name: "woo_update_cart_item",
    description: "Update quantity of a cart item.",
    inputSchema: {
      type: "object",
      properties: {
        item_key: { type: "string", description: "Cart item key" },
        quantity: { type: "number" },
        cart_key: { type: "string" },
      },
      required: ["item_key", "quantity"],
    },
  },
  {
    name: "woo_remove_cart_item",
    description: "Remove an item from the cart.",
    inputSchema: {
      type: "object",
      properties: {
        item_key: { type: "string" },
        cart_key: { type: "string" },
      },
      required: ["item_key"],
    },
  },
  {
    name: "woo_apply_coupon",
    description: "Apply a coupon code to the cart.",
    inputSchema: {
      type: "object",
      properties: {
        coupon_code: { type: "string" },
        cart_key: { type: "string" },
      },
      required: ["coupon_code"],
    },
  },
  {
    name: "woo_clear_cart",
    description: "Clear all items from the cart.",
    inputSchema: {
      type: "object",
      properties: { cart_key: { type: "string" } },
    },
  },

  // ── Coupons ──
  {
    name: "woo_list_coupons",
    description: "List all coupons.",
    inputSchema: {
      type: "object",
      properties: { per_page: { type: "number" }, search: { type: "string" } },
    },
  },
  {
    name: "woo_create_coupon",
    description: "Create a coupon with discount type, amount, restrictions, usage limits, and expiry.",
    inputSchema: {
      type: "object",
      properties: {
        code: { type: "string" },
        discount_type: { type: "string", description: "percent, fixed_cart, fixed_product" },
        amount: { type: "string" },
        description: { type: "string" },
        date_expires: { type: "string", description: "Expiry date ISO 8601" },
        individual_use: { type: "boolean" },
        product_ids: { type: "array", items: { type: "number" } },
        excluded_product_ids: { type: "array", items: { type: "number" } },
        usage_limit: { type: "number" },
        usage_limit_per_user: { type: "number" },
        free_shipping: { type: "boolean" },
        minimum_amount: { type: "string" },
        maximum_amount: { type: "string" },
        email_restrictions: { type: "array", items: { type: "string" } },
      },
      required: ["code", "amount"],
    },
  },

  // ── Customers ──
  {
    name: "woo_list_customers",
    description: "List WooCommerce customers with search, role filter, and order count.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        search: { type: "string" },
        role: { type: "string", description: "customer, subscriber, etc." },
        orderby: { type: "string" },
      },
    },
  },
  {
    name: "woo_get_customer",
    description: "Get full customer profile: orders, billing/shipping addresses, spending totals.",
    inputSchema: {
      type: "object",
      properties: { customer_id: { type: "number" } },
      required: ["customer_id"],
    },
  },

  // ── Shipping & Tax ──
  {
    name: "woo_list_shipping_zones",
    description: "List shipping zones and their methods.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "woo_list_tax_classes",
    description: "List tax classes.",
    inputSchema: { type: "object", properties: {} },
  },

  // ── Reports ──
  {
    name: "woo_sales_report",
    description: "Get sales report (totals, orders count, items sold, revenue). Filter by date range.",
    inputSchema: {
      type: "object",
      properties: {
        period: { type: "string", description: "week, month, last_month, year" },
        date_min: { type: "string" },
        date_max: { type: "string" },
      },
    },
  },
  {
    name: "woo_top_sellers",
    description: "Get top selling products report.",
    inputSchema: {
      type: "object",
      properties: {
        period: { type: "string" },
        date_min: { type: "string" },
        date_max: { type: "string" },
      },
    },
  },

  // ── Settings ──
  {
    name: "woo_get_settings",
    description: "Get WooCommerce settings for a specific group (general, products, tax, shipping, checkout, account, email, advanced).",
    inputSchema: {
      type: "object",
      properties: {
        group: { type: "string", description: "Settings group ID" },
      },
      required: ["group"],
    },
  },
  {
    name: "woo_update_setting",
    description: "Update a WooCommerce setting.",
    inputSchema: {
      type: "object",
      properties: {
        group: { type: "string" },
        setting_id: { type: "string" },
        value: { type: "string" },
      },
      required: ["group", "setting_id", "value"],
    },
  },
];

// WooCommerce uses a separate API base: /wp-json/wc/v3/
export async function handleWooTools(name, args, wooFetch, wpCustomFetch) {
  switch (name) {
    // ── Products ──
    case "woo_list_products": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, String(v));
      return await wooFetch(`/products?${params}`);
    }
    case "woo_get_product":
      return await wooFetch(`/products/${args.product_id}`);
    case "woo_create_product": {
      return await wooFetch("/products", { method: "POST", body: JSON.stringify(args) });
    }
    case "woo_update_product": {
      const { product_id, ...body } = args;
      return await wooFetch(`/products/${product_id}`, { method: "PUT", body: JSON.stringify(body) });
    }
    case "woo_delete_product":
      return await wooFetch(`/products/${args.product_id}?force=${args.force || false}`, { method: "DELETE" });
    case "woo_bulk_update_products":
      return await wooFetch("/products/batch", { method: "POST", body: JSON.stringify(args) });

    // ── Variations ──
    case "woo_list_variations": {
      const params = new URLSearchParams();
      if (args.per_page) params.set("per_page", args.per_page);
      return await wooFetch(`/products/${args.product_id}/variations?${params}`);
    }
    case "woo_create_variation": {
      const { product_id, ...body } = args;
      return await wooFetch(`/products/${product_id}/variations`, { method: "POST", body: JSON.stringify(body) });
    }
    case "woo_update_variation": {
      const { product_id, variation_id, ...body } = args;
      return await wooFetch(`/products/${product_id}/variations/${variation_id}`, { method: "PUT", body: JSON.stringify(body) });
    }

    // ── Product Categories ──
    case "woo_list_product_categories": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, v);
      return await wooFetch(`/products/categories?${params}`);
    }
    case "woo_create_product_category":
      return await wooFetch("/products/categories", { method: "POST", body: JSON.stringify(args) });

    // ── Orders ──
    case "woo_list_orders": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, String(v));
      return await wooFetch(`/orders?${params}`);
    }
    case "woo_get_order":
      return await wooFetch(`/orders/${args.order_id}`);
    case "woo_create_order":
      return await wooFetch("/orders", { method: "POST", body: JSON.stringify(args) });
    case "woo_update_order": {
      const { order_id, ...body } = args;
      return await wooFetch(`/orders/${order_id}`, { method: "PUT", body: JSON.stringify(body) });
    }
    case "woo_add_order_note":
      return await wooFetch(`/orders/${args.order_id}/notes`, {
        method: "POST",
        body: JSON.stringify({ note: args.note, customer_note: args.customer_note || false }),
      });
    case "woo_create_refund": {
      const { order_id, ...body } = args;
      return await wooFetch(`/orders/${order_id}/refunds`, { method: "POST", body: JSON.stringify(body) });
    }

    // ── Cart (via WP-MCP companion plugin or CoCart) ──
    case "woo_get_cart":
      return await wpCustomFetch(`/wp-mcp/v1/cart${args.cart_key ? `?cart_key=${args.cart_key}` : ""}`);
    case "woo_add_to_cart":
      return await wpCustomFetch("/wp-mcp/v1/cart/add", { method: "POST", body: JSON.stringify(args) });
    case "woo_update_cart_item":
      return await wpCustomFetch("/wp-mcp/v1/cart/update", { method: "POST", body: JSON.stringify(args) });
    case "woo_remove_cart_item":
      return await wpCustomFetch("/wp-mcp/v1/cart/remove", { method: "POST", body: JSON.stringify(args) });
    case "woo_apply_coupon":
      return await wpCustomFetch("/wp-mcp/v1/cart/coupon", { method: "POST", body: JSON.stringify(args) });
    case "woo_clear_cart":
      return await wpCustomFetch("/wp-mcp/v1/cart/clear", { method: "POST", body: JSON.stringify(args) });

    // ── Coupons ──
    case "woo_list_coupons": {
      const params = new URLSearchParams();
      if (args.per_page) params.set("per_page", args.per_page);
      if (args.search) params.set("search", args.search);
      return await wooFetch(`/coupons?${params}`);
    }
    case "woo_create_coupon":
      return await wooFetch("/coupons", { method: "POST", body: JSON.stringify(args) });

    // ── Customers ──
    case "woo_list_customers": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, v);
      return await wooFetch(`/customers?${params}`);
    }
    case "woo_get_customer":
      return await wooFetch(`/customers/${args.customer_id}`);

    // ── Shipping & Tax ──
    case "woo_list_shipping_zones":
      return await wooFetch("/shipping/zones");
    case "woo_list_tax_classes":
      return await wooFetch("/taxes/classes");

    // ── Reports ──
    case "woo_sales_report": {
      const params = new URLSearchParams();
      if (args.period) params.set("period", args.period);
      if (args.date_min) params.set("date_min", args.date_min);
      if (args.date_max) params.set("date_max", args.date_max);
      return await wooFetch(`/reports/sales?${params}`);
    }
    case "woo_top_sellers": {
      const params = new URLSearchParams();
      if (args.period) params.set("period", args.period);
      return await wooFetch(`/reports/top_sellers?${params}`);
    }

    // ── Settings ──
    case "woo_get_settings":
      return await wooFetch(`/settings/${args.group}`);
    case "woo_update_setting":
      return await wooFetch(`/settings/${args.group}/${args.setting_id}`, {
        method: "PUT",
        body: JSON.stringify({ value: args.value }),
      });

    default:
      return null;
  }
}
