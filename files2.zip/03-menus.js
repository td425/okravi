/**
 * SECTION 3: Menus & Navigation (including Mega Menus)
 * Manages WordPress nav menus, menu items, locations, and mega menu structures.
 * Requires WP 5.9+ for navigation block endpoints, or the companion plugin for classic menus.
 */

export const menuTools = [
  {
    name: "list_menus",
    description: "List all registered navigation menus with their locations and item count.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "get_menu",
    description: "Get a menu and all its items (with hierarchy) by menu ID or slug.",
    inputSchema: {
      type: "object",
      properties: {
        menu_id: { type: "number", description: "Menu term ID" },
        menu_slug: { type: "string", description: "Menu slug (alternative to ID)" },
      },
    },
  },
  {
    name: "create_menu",
    description: "Create a new navigation menu and optionally assign it to a theme location.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string", description: "Menu name" },
        location: { type: "string", description: "Theme location slug (e.g., primary, footer)" },
      },
      required: ["name"],
    },
  },
  {
    name: "delete_menu",
    description: "Delete a navigation menu by ID.",
    inputSchema: {
      type: "object",
      properties: { menu_id: { type: "number" } },
      required: ["menu_id"],
    },
  },
  {
    name: "add_menu_item",
    description: "Add an item to a menu. Supports pages, posts, custom links, categories, and mega menu columns.",
    inputSchema: {
      type: "object",
      properties: {
        menu_id: { type: "number", description: "Target menu ID" },
        title: { type: "string", description: "Display label" },
        url: { type: "string", description: "URL for custom links" },
        object_type: { type: "string", description: "Type: page, post, custom, category, tag" },
        object_id: { type: "number", description: "ID of linked object (page/post/category)" },
        parent_item_id: { type: "number", description: "Parent menu item ID (for dropdowns/sub-items)" },
        position: { type: "number", description: "Order position" },
        css_classes: { type: "string", description: "Space-separated CSS classes (e.g., 'mega-menu-column')" },
        description: { type: "string", description: "Item description (used by some themes in mega menus)" },
        target: { type: "string", description: "_blank for new tab" },
        attr_title: { type: "string", description: "Title attribute / tooltip" },
      },
      required: ["menu_id", "title"],
    },
  },
  {
    name: "update_menu_item",
    description: "Update an existing menu item (title, URL, parent, position, classes).",
    inputSchema: {
      type: "object",
      properties: {
        item_id: { type: "number" },
        title: { type: "string" },
        url: { type: "string" },
        parent_item_id: { type: "number" },
        position: { type: "number" },
        css_classes: { type: "string" },
        description: { type: "string" },
        target: { type: "string" },
      },
      required: ["item_id"],
    },
  },
  {
    name: "delete_menu_item",
    description: "Remove an item from a menu.",
    inputSchema: {
      type: "object",
      properties: {
        item_id: { type: "number" },
        force: { type: "boolean" },
      },
      required: ["item_id"],
    },
  },
  {
    name: "reorder_menu_items",
    description: "Reorder items in a menu by providing an ordered array of item IDs.",
    inputSchema: {
      type: "object",
      properties: {
        menu_id: { type: "number" },
        item_order: { type: "array", items: { type: "number" }, description: "Item IDs in desired order" },
      },
      required: ["menu_id", "item_order"],
    },
  },
  {
    name: "list_menu_locations",
    description: "List all theme-registered menu locations and which menu is assigned to each.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "assign_menu_location",
    description: "Assign a menu to a theme location.",
    inputSchema: {
      type: "object",
      properties: {
        menu_id: { type: "number" },
        location: { type: "string", description: "Theme location slug" },
      },
      required: ["menu_id", "location"],
    },
  },
  {
    name: "create_mega_menu",
    description: "Create a complete mega menu structure: a top-level item with columns and sub-items. Uses CSS classes to flag mega menu behavior (requires theme/plugin support like Max Mega Menu or WP Mega Menu).",
    inputSchema: {
      type: "object",
      properties: {
        menu_id: { type: "number", description: "Target menu ID" },
        title: { type: "string", description: "Top-level trigger label" },
        columns: {
          type: "array",
          description: "Array of column objects. Each column has a heading and items array.",
          items: {
            type: "object",
            properties: {
              heading: { type: "string", description: "Column heading" },
              items: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    url: { type: "string" },
                    object_type: { type: "string" },
                    object_id: { type: "number" },
                  },
                  required: ["title"],
                },
              },
            },
            required: ["heading", "items"],
          },
        },
        mega_class: { type: "string", description: "CSS class for mega menu trigger (default: mega-menu)" },
      },
      required: ["menu_id", "title", "columns"],
    },
  },
];

export async function handleMenuTools(name, args, wpFetch, wpCustomFetch) {
  // Helper: many menu operations go through the custom WP-MCP plugin endpoint
  // Fallback to navigation blocks API if available

  switch (name) {
    case "list_menus": {
      // Try custom plugin endpoint first, then WP navigation blocks
      try {
        const menus = await wpCustomFetch("/wp-mcp/v1/menus");
        return menus;
      } catch {
        // Fallback: list navigation post type (WP 5.9+ FSE)
        try {
          const navs = await wpFetch("/navigation?per_page=100");
          return navs.map((n) => ({
            id: n.id,
            title: n.title.rendered,
            status: n.status,
            slug: n.slug,
          }));
        } catch {
          return { error: "Menu API not available. Install the WP-MCP companion plugin or use a FSE theme." };
        }
      }
    }

    case "get_menu": {
      try {
        const endpoint = args.menu_id
          ? `/wp-mcp/v1/menus/${args.menu_id}`
          : `/wp-mcp/v1/menus/slug/${args.menu_slug}`;
        return await wpCustomFetch(endpoint);
      } catch {
        if (args.menu_id) {
          const nav = await wpFetch(`/navigation/${args.menu_id}?context=edit`);
          return {
            id: nav.id,
            title: nav.title.rendered ?? nav.title.raw,
            content: nav.content.rendered ?? nav.content.raw,
            status: nav.status,
          };
        }
        return { error: "Menu not found." };
      }
    }

    case "create_menu": {
      try {
        return await wpCustomFetch("/wp-mcp/v1/menus", {
          method: "POST",
          body: JSON.stringify({ name: args.name, location: args.location }),
        });
      } catch {
        // FSE fallback: create navigation post
        const nav = await wpFetch("/navigation", {
          method: "POST",
          body: JSON.stringify({
            title: args.name,
            content: "<!-- wp:navigation-link /-->",
            status: "publish",
          }),
        });
        return { id: nav.id, title: nav.title.rendered, message: "Navigation menu created (FSE)." };
      }
    }

    case "delete_menu": {
      try {
        return await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}`, { method: "DELETE" });
      } catch {
        await wpFetch(`/navigation/${args.menu_id}?force=true`, { method: "DELETE" });
        return { message: `Menu ${args.menu_id} deleted.` };
      }
    }

    case "add_menu_item": {
      const body = { ...args };
      delete body.menu_id;
      return await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}/items`, {
        method: "POST",
        body: JSON.stringify(body),
      });
    }

    case "update_menu_item": {
      const { item_id, ...body } = args;
      return await wpCustomFetch(`/wp-mcp/v1/menu-items/${item_id}`, {
        method: "POST",
        body: JSON.stringify(body),
      });
    }

    case "delete_menu_item": {
      const qs = args.force ? "?force=true" : "";
      return await wpCustomFetch(`/wp-mcp/v1/menu-items/${args.item_id}${qs}`, {
        method: "DELETE",
      });
    }

    case "reorder_menu_items": {
      return await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}/reorder`, {
        method: "POST",
        body: JSON.stringify({ item_order: args.item_order }),
      });
    }

    case "list_menu_locations": {
      return await wpCustomFetch("/wp-mcp/v1/menu-locations");
    }

    case "assign_menu_location": {
      return await wpCustomFetch("/wp-mcp/v1/menu-locations", {
        method: "POST",
        body: JSON.stringify({ menu_id: args.menu_id, location: args.location }),
      });
    }

    case "create_mega_menu": {
      const megaClass = args.mega_class || "mega-menu";
      // Step 1: Create top-level item
      const topItem = await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}/items`, {
        method: "POST",
        body: JSON.stringify({
          title: args.title,
          url: "#",
          object_type: "custom",
          css_classes: megaClass,
        }),
      });

      // Step 2: Create columns and their items
      const columnsResult = [];
      for (let i = 0; i < args.columns.length; i++) {
        const col = args.columns[i];
        // Column heading as a sub-item
        const colItem = await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}/items`, {
          method: "POST",
          body: JSON.stringify({
            title: col.heading,
            url: "#",
            object_type: "custom",
            parent_item_id: topItem.id,
            position: i,
            css_classes: "mega-menu-column",
          }),
        });

        const subItems = [];
        for (let j = 0; j < col.items.length; j++) {
          const item = col.items[j];
          const subItem = await wpCustomFetch(`/wp-mcp/v1/menus/${args.menu_id}/items`, {
            method: "POST",
            body: JSON.stringify({
              title: item.title,
              url: item.url || "#",
              object_type: item.object_type || "custom",
              object_id: item.object_id,
              parent_item_id: colItem.id,
              position: j,
            }),
          });
          subItems.push({ id: subItem.id, title: item.title });
        }

        columnsResult.push({
          column_id: colItem.id,
          heading: col.heading,
          items: subItems,
        });
      }

      return {
        top_item_id: topItem.id,
        title: args.title,
        columns: columnsResult,
        message: `Mega menu "${args.title}" created with ${args.columns.length} columns.`,
      };
    }

    default:
      return null;
  }
}
