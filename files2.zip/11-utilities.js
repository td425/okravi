/**
 * SECTION 11: Site Settings, Comments, Search/Replace, and Utilities
 * General WP settings, site health, comments, widgets, sidebars, cron, site export/import.
 */

export const utilityTools = [
  // ── Site Info & Settings ──
  {
    name: "get_site_info",
    description: "Get WordPress site info: name, URL, description, timezone, WP version, PHP version, active theme, permalink structure.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "get_site_settings",
    description: "Get WordPress general settings: title, tagline, URL, email, timezone, date/time format, language, etc.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "update_site_settings",
    description: "Update WordPress settings (title, tagline, timezone, date format, etc.).",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string" },
        description: { type: "string", description: "Site tagline" },
        url: { type: "string" },
        email: { type: "string" },
        timezone: { type: "string" },
        date_format: { type: "string" },
        time_format: { type: "string" },
        start_of_week: { type: "number" },
        language: { type: "string" },
        posts_per_page: { type: "number" },
        default_comment_status: { type: "string", description: "open or closed" },
        default_ping_status: { type: "string" },
        use_smilies: { type: "boolean" },
      },
    },
  },
  {
    name: "get_permalink_structure",
    description: "Get the current permalink structure.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "update_permalink_structure",
    description: "Update the permalink structure (e.g., '/%postname%/', '/%year%/%monthnum%/%postname%/').",
    inputSchema: {
      type: "object",
      properties: {
        structure: { type: "string", description: "Permalink structure string" },
      },
      required: ["structure"],
    },
  },

  // ── Comments ──
  {
    name: "list_comments",
    description: "List comments with filtering by post, status, author, type, date.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number" },
        page: { type: "number" },
        post: { type: "number" },
        status: { type: "string", description: "approve, hold, trash, spam" },
        search: { type: "string" },
        author_email: { type: "string" },
        type: { type: "string", description: "comment, pingback, trackback" },
        after: { type: "string" },
        before: { type: "string" },
        orderby: { type: "string" },
        order: { type: "string" },
      },
    },
  },
  {
    name: "get_comment",
    description: "Get a single comment by ID.",
    inputSchema: {
      type: "object",
      properties: { comment_id: { type: "number" } },
      required: ["comment_id"],
    },
  },
  {
    name: "create_comment",
    description: "Create a new comment on a post.",
    inputSchema: {
      type: "object",
      properties: {
        post: { type: "number" },
        content: { type: "string" },
        author_name: { type: "string" },
        author_email: { type: "string" },
        author_url: { type: "string" },
        parent: { type: "number", description: "Parent comment ID for replies" },
        status: { type: "string" },
      },
      required: ["post", "content"],
    },
  },
  {
    name: "update_comment",
    description: "Update a comment: change status, content, author info.",
    inputSchema: {
      type: "object",
      properties: {
        comment_id: { type: "number" },
        content: { type: "string" },
        status: { type: "string", description: "approved, hold, trash, spam" },
        author_name: { type: "string" },
        author_email: { type: "string" },
      },
      required: ["comment_id"],
    },
  },
  {
    name: "delete_comment",
    description: "Delete a comment.",
    inputSchema: {
      type: "object",
      properties: {
        comment_id: { type: "number" },
        force: { type: "boolean" },
      },
      required: ["comment_id"],
    },
  },
  {
    name: "bulk_moderate_comments",
    description: "Bulk approve, trash, spam, or delete multiple comments.",
    inputSchema: {
      type: "object",
      properties: {
        comment_ids: { type: "array", items: { type: "number" } },
        action: { type: "string", description: "approve, hold, trash, spam, delete" },
      },
      required: ["comment_ids", "action"],
    },
  },

  // ── Widgets & Sidebars ──
  {
    name: "list_sidebars",
    description: "List registered widget areas/sidebars.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "list_widgets",
    description: "List widgets in a sidebar or all widgets.",
    inputSchema: {
      type: "object",
      properties: {
        sidebar: { type: "string", description: "Sidebar ID (optional)" },
      },
    },
  },
  {
    name: "add_widget",
    description: "Add a widget to a sidebar.",
    inputSchema: {
      type: "object",
      properties: {
        sidebar: { type: "string" },
        widget_type: { type: "string", description: "Widget type (e.g., 'text', 'recent-posts', 'custom_html')" },
        settings: { type: "object", description: "Widget settings (title, content, etc.)" },
        position: { type: "number" },
      },
      required: ["sidebar", "widget_type"],
    },
  },
  {
    name: "update_widget",
    description: "Update widget settings.",
    inputSchema: {
      type: "object",
      properties: {
        widget_id: { type: "string" },
        settings: { type: "object" },
        sidebar: { type: "string", description: "Move to different sidebar" },
      },
      required: ["widget_id"],
    },
  },
  {
    name: "delete_widget",
    description: "Remove a widget from a sidebar.",
    inputSchema: {
      type: "object",
      properties: { widget_id: { type: "string" } },
      required: ["widget_id"],
    },
  },

  // ── Cron Jobs ──
  {
    name: "list_cron_events",
    description: "List all scheduled WordPress cron events with next run time, recurrence, and hook name.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "create_cron_event",
    description: "Schedule a new cron event.",
    inputSchema: {
      type: "object",
      properties: {
        hook: { type: "string", description: "Action hook name" },
        recurrence: { type: "string", description: "hourly, twicedaily, daily, weekly, or timestamp for one-time" },
        first_run: { type: "string", description: "ISO 8601 datetime for first run (default: now)" },
        args: { type: "array", description: "Arguments to pass to the hook" },
      },
      required: ["hook", "recurrence"],
    },
  },
  {
    name: "delete_cron_event",
    description: "Delete/unschedule a cron event.",
    inputSchema: {
      type: "object",
      properties: {
        hook: { type: "string" },
        timestamp: { type: "number", description: "Specific event timestamp to delete" },
      },
      required: ["hook"],
    },
  },
  {
    name: "run_cron_event",
    description: "Trigger a cron event to run immediately.",
    inputSchema: {
      type: "object",
      properties: { hook: { type: "string" } },
      required: ["hook"],
    },
  },

  // ── Site Health ──
  {
    name: "get_site_health",
    description: "Get WordPress site health status: critical issues, recommendations, passed tests, server info.",
    inputSchema: { type: "object", properties: {} },
  },

  // ── Export / Import ──
  {
    name: "export_content",
    description: "Export WordPress content as WXR (WordPress eXtended RSS) XML. Filter by type, status, date range.",
    inputSchema: {
      type: "object",
      properties: {
        content_type: { type: "string", description: "all, posts, pages, media, nav_menu_item" },
        status: { type: "string" },
        start_date: { type: "string" },
        end_date: { type: "string" },
        category: { type: "number" },
      },
    },
  },
];

export async function handleUtilityTools(name, args, wpFetch, wpCustomFetch) {
  switch (name) {
    // ── Site Info ──
    case "get_site_info": {
      const info = await wpCustomFetch("/wp-mcp/v1/site/info");
      return info;
    }
    case "get_site_settings":
      return await wpFetch("/settings");
    case "update_site_settings":
      return await wpFetch("/settings", { method: "POST", body: JSON.stringify(args) });
    case "get_permalink_structure":
      return await wpCustomFetch("/wp-mcp/v1/site/permalinks");
    case "update_permalink_structure":
      return await wpCustomFetch("/wp-mcp/v1/site/permalinks", { method: "POST", body: JSON.stringify(args) });

    // ── Comments ──
    case "list_comments": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) if (v !== undefined) params.set(k, String(v));
      const comments = await wpFetch(`/comments?${params}`);
      return comments.map((c) => ({
        id: c.id, post: c.post, author_name: c.author_name,
        author_email: c.author_email, content: c.content.rendered,
        status: c.status, date: c.date, parent: c.parent, type: c.type,
      }));
    }
    case "get_comment":
      return await wpFetch(`/comments/${args.comment_id}`);
    case "create_comment":
      return await wpFetch("/comments", { method: "POST", body: JSON.stringify(args) });
    case "update_comment": {
      const { comment_id, ...body } = args;
      return await wpFetch(`/comments/${comment_id}`, { method: "POST", body: JSON.stringify(body) });
    }
    case "delete_comment":
      return await wpFetch(`/comments/${args.comment_id}?force=${args.force || false}`, { method: "DELETE" });
    case "bulk_moderate_comments": {
      const results = [];
      for (const id of args.comment_ids) {
        try {
          if (args.action === "delete") {
            await wpFetch(`/comments/${id}?force=true`, { method: "DELETE" });
          } else {
            const statusMap = { approve: "approved", hold: "hold", trash: "trash", spam: "spam" };
            await wpFetch(`/comments/${id}`, { method: "POST", body: JSON.stringify({ status: statusMap[args.action] || args.action }) });
          }
          results.push({ id, status: "done" });
        } catch (e) {
          results.push({ id, status: "error", error: e.message });
        }
      }
      return { results };
    }

    // ── Widgets & Sidebars ──
    case "list_sidebars":
      return await wpFetch("/sidebars");
    case "list_widgets": {
      if (args.sidebar) return await wpFetch(`/sidebars/${args.sidebar}`);
      return await wpFetch("/widgets");
    }
    case "add_widget":
      return await wpFetch("/widgets", { method: "POST", body: JSON.stringify({ id_base: args.widget_type, sidebar: args.sidebar, instance: { raw: args.settings }, position: args.position }) });
    case "update_widget": {
      const { widget_id, ...body } = args;
      const payload = {};
      if (body.settings) payload.instance = { raw: body.settings };
      if (body.sidebar) payload.sidebar = body.sidebar;
      return await wpFetch(`/widgets/${widget_id}`, { method: "POST", body: JSON.stringify(payload) });
    }
    case "delete_widget":
      return await wpFetch(`/widgets/${args.widget_id}?force=true`, { method: "DELETE" });

    // ── Cron ──
    case "list_cron_events":
      return await wpCustomFetch("/wp-mcp/v1/cron/events");
    case "create_cron_event":
      return await wpCustomFetch("/wp-mcp/v1/cron/events", { method: "POST", body: JSON.stringify(args) });
    case "delete_cron_event":
      return await wpCustomFetch("/wp-mcp/v1/cron/events", { method: "DELETE", body: JSON.stringify(args) });
    case "run_cron_event":
      return await wpCustomFetch(`/wp-mcp/v1/cron/events/${encodeURIComponent(args.hook)}/run`, { method: "POST" });

    // ── Site Health ──
    case "get_site_health":
      return await wpCustomFetch("/wp-mcp/v1/site/health");

    // ── Export ──
    case "export_content":
      return await wpCustomFetch("/wp-mcp/v1/site/export", { method: "POST", body: JSON.stringify(args) });

    default:
      return null;
  }
}
