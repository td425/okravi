/**
 * SECTION 1: Pages & Content Management
 * Full CRUD for pages, content blocks, revisions, page meta, templates
 */

export const pageTools = [
  {
    name: "list_pages",
    description: "List all pages with filtering by status, parent, author, search term. Returns id, title, status, slug, link, template, parent, modified date.",
    inputSchema: {
      type: "object",
      properties: {
        per_page: { type: "number", description: "Results per page (max 100, default 20)" },
        page: { type: "number", description: "Page number for pagination" },
        status: { type: "string", description: "Filter: publish, draft, private, pending, trash, any" },
        search: { type: "string", description: "Search by keyword" },
        parent: { type: "number", description: "Filter by parent page ID (0 for top-level)" },
        orderby: { type: "string", description: "Order by: date, title, slug, modified, menu_order, id" },
        order: { type: "string", description: "asc or desc" },
        author: { type: "number", description: "Filter by author user ID" },
      },
    },
  },
  {
    name: "get_page",
    description: "Get a single page by ID. Returns full HTML content, raw content (block markup), title, status, template, featured image, meta fields, and revision count.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "The page ID" },
        context: { type: "string", description: "view or edit (edit returns raw content)" },
      },
      required: ["page_id"],
    },
  },
  {
    name: "create_page",
    description: "Create a new WordPress page. Supports HTML content, Gutenberg block markup, page templates, parent pages, featured images, custom meta fields, and menu order.",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string", description: "Page title" },
        content: { type: "string", description: "Page content — HTML or Gutenberg block markup (e.g., <!-- wp:paragraph --><p>text</p><!-- /wp:paragraph -->)" },
        status: { type: "string", description: "draft, publish, private, pending (default: draft)" },
        parent: { type: "number", description: "Parent page ID for hierarchy" },
        slug: { type: "string", description: "URL slug" },
        template: { type: "string", description: "Page template file (e.g., template-fullwidth.php)" },
        menu_order: { type: "number", description: "Order position in menus/lists" },
        featured_media: { type: "number", description: "Featured image media ID" },
        excerpt: { type: "string", description: "Page excerpt" },
        meta: { type: "object", description: "Custom meta fields as key-value pairs" },
        comment_status: { type: "string", description: "open or closed" },
      },
      required: ["title", "content"],
    },
  },
  {
    name: "update_page",
    description: "Update an existing page. Any field not provided is left unchanged. Supports content, title, status, template, meta, featured image, etc.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "The page ID to update" },
        title: { type: "string" },
        content: { type: "string", description: "New content (HTML or block markup)" },
        status: { type: "string" },
        slug: { type: "string" },
        template: { type: "string" },
        parent: { type: "number" },
        menu_order: { type: "number" },
        featured_media: { type: "number" },
        excerpt: { type: "string" },
        meta: { type: "object" },
        comment_status: { type: "string" },
      },
      required: ["page_id"],
    },
  },
  {
    name: "delete_page",
    description: "Delete a page. By default moves to trash; use force=true to permanently delete.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "Page ID to delete" },
        force: { type: "boolean", description: "Permanently delete (skip trash)" },
      },
      required: ["page_id"],
    },
  },
  {
    name: "list_page_revisions",
    description: "List all revisions for a page. Useful for seeing edit history and rolling back changes.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "The page ID" },
      },
      required: ["page_id"],
    },
  },
  {
    name: "restore_page_revision",
    description: "Restore a page to a previous revision.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "The page ID" },
        revision_id: { type: "number", description: "The revision ID to restore" },
      },
      required: ["page_id", "revision_id"],
    },
  },
  {
    name: "duplicate_page",
    description: "Duplicate a page with all its content and meta. Creates a draft copy.",
    inputSchema: {
      type: "object",
      properties: {
        page_id: { type: "number", description: "Source page ID to duplicate" },
        new_title: { type: "string", description: "Title for the copy (default: 'Copy of [original]')" },
      },
      required: ["page_id"],
    },
  },
  {
    name: "bulk_update_pages",
    description: "Update multiple pages at once. Useful for changing status, template, or parent of many pages.",
    inputSchema: {
      type: "object",
      properties: {
        page_ids: { type: "array", items: { type: "number" }, description: "Array of page IDs" },
        status: { type: "string", description: "New status for all" },
        template: { type: "string", description: "New template for all" },
        parent: { type: "number", description: "New parent for all" },
      },
      required: ["page_ids"],
    },
  },
];

export async function handlePageTools(name, args, wpFetch) {
  switch (name) {
    case "list_pages": {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(args)) {
        if (v !== undefined) params.set(k, v);
      }
      const pages = await wpFetch(`/pages?${params}`);
      return pages.map((p) => ({
        id: p.id,
        title: p.title.rendered,
        status: p.status,
        slug: p.slug,
        link: p.link,
        template: p.template,
        parent: p.parent,
        menu_order: p.menu_order,
        modified: p.modified,
        author: p.author,
      }));
    }

    case "get_page": {
      const ctx = args.context === "edit" ? "?context=edit" : "";
      const page = await wpFetch(`/pages/${args.page_id}${ctx}`);
      return {
        id: page.id,
        title: page.title.rendered ?? page.title.raw,
        content_rendered: page.content.rendered,
        content_raw: page.content.raw ?? null,
        status: page.status,
        slug: page.slug,
        link: page.link,
        template: page.template,
        parent: page.parent,
        featured_media: page.featured_media,
        meta: page.meta,
        modified: page.modified,
        excerpt: page.excerpt?.rendered,
      };
    }

    case "create_page": {
      const body = { ...args };
      delete body.page_id;
      if (!body.status) body.status = "draft";
      const page = await wpFetch("/pages", {
        method: "POST",
        body: JSON.stringify(body),
      });
      return {
        id: page.id,
        title: page.title.rendered,
        status: page.status,
        link: page.link,
        message: `Page "${page.title.rendered}" created as ${page.status}.`,
      };
    }

    case "update_page": {
      const { page_id, ...body } = args;
      const page = await wpFetch(`/pages/${page_id}`, {
        method: "POST",
        body: JSON.stringify(body),
      });
      return {
        id: page.id,
        title: page.title.rendered,
        status: page.status,
        link: page.link,
        message: `Page "${page.title.rendered}" updated.`,
      };
    }

    case "delete_page": {
      const qs = args.force ? "?force=true" : "";
      const page = await wpFetch(`/pages/${args.page_id}${qs}`, { method: "DELETE" });
      return { id: page.id, message: `Page deleted.` };
    }

    case "list_page_revisions": {
      const revisions = await wpFetch(`/pages/${args.page_id}/revisions`);
      return revisions.map((r) => ({
        id: r.id,
        date: r.date,
        author: r.author,
        title: r.title.rendered,
        content_length: r.content.rendered?.length ?? 0,
      }));
    }

    case "restore_page_revision": {
      const revision = await wpFetch(`/pages/${args.page_id}/revisions/${args.revision_id}`);
      const restored = await wpFetch(`/pages/${args.page_id}`, {
        method: "POST",
        body: JSON.stringify({
          title: revision.title.rendered ?? revision.title.raw,
          content: revision.content.rendered ?? revision.content.raw,
        }),
      });
      return {
        id: restored.id,
        message: `Page restored to revision ${args.revision_id}.`,
      };
    }

    case "duplicate_page": {
      const source = await wpFetch(`/pages/${args.page_id}?context=edit`);
      const newPage = await wpFetch("/pages", {
        method: "POST",
        body: JSON.stringify({
          title: args.new_title || `Copy of ${source.title.raw || source.title.rendered}`,
          content: source.content.raw || source.content.rendered,
          status: "draft",
          template: source.template,
          parent: source.parent,
          meta: source.meta,
          excerpt: source.excerpt?.raw || source.excerpt?.rendered || "",
        }),
      });
      return {
        id: newPage.id,
        title: newPage.title.rendered,
        message: `Duplicated page ${args.page_id} → new page ${newPage.id} (draft).`,
      };
    }

    case "bulk_update_pages": {
      const results = [];
      for (const id of args.page_ids) {
        const body = {};
        if (args.status) body.status = args.status;
        if (args.template) body.template = args.template;
        if (args.parent !== undefined) body.parent = args.parent;
        try {
          const p = await wpFetch(`/pages/${id}`, {
            method: "POST",
            body: JSON.stringify(body),
          });
          results.push({ id: p.id, title: p.title.rendered, status: "updated" });
        } catch (e) {
          results.push({ id, status: "error", error: e.message });
        }
      }
      return { updated: results.length, results };
    }

    default:
      return null;
  }
}
