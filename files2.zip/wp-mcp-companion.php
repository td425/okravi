<?php
/**
 * Plugin Name: WP-MCP Companion
 * Description: REST API endpoints for the WordPress Ultimate MCP Server. Provides database, filesystem, menu, cache, cron, multisite, and advanced management APIs.
 * Version: 1.0.0
 * Author: WP-MCP
 * Requires PHP: 7.4
 * Requires at least: 5.9
 *
 * SECURITY: All endpoints require administrator authentication.
 * Install only on sites where the MCP server has authorized access.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WP_MCP_Companion {
    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function check_admin( $r ) { return current_user_can( 'manage_options' ); }

    private function reg( $ns, $route, $methods, $cb ) {
        register_rest_route( $ns, $route, [ 'methods' => $methods, 'callback' => [ $this, $cb ], 'permission_callback' => [ $this, 'check_admin' ] ] );
    }

    public function register_routes() {
        $ns = 'wp-mcp/v1';

        // Database
        $this->reg($ns, '/db/query', 'POST', 'db_query');
        $this->reg($ns, '/db/tables', 'GET', 'db_list_tables');
        $this->reg($ns, '/db/tables/(?P<t>[\\w-]+)/describe', 'GET', 'db_describe');
        $this->reg($ns, '/db/tables/create', 'POST', 'db_create_table');
        $this->reg($ns, '/db/tables/(?P<t>[\\w-]+)', 'DELETE', 'db_drop_table');
        $this->reg($ns, '/db/tables/(?P<t>[\\w-]+)/alter', 'POST', 'db_alter_table');
        $this->reg($ns, '/db/tables/(?P<t>[\\w-]+)/export', 'POST', 'db_export');
        $this->reg($ns, '/db/tables/(?P<t>[\\w-]+)/import', 'POST', 'db_import');
        $this->reg($ns, '/db/prefix', 'GET', 'db_prefix');
        $this->reg($ns, '/db/options/(?P<n>.+)', 'GET', 'db_get_option');
        $this->reg($ns, '/db/options', 'POST', 'db_update_option');
        $this->reg($ns, '/db/search-replace', 'POST', 'db_search_replace');

        // Filesystem
        foreach (['list','read','write','edit','delete','copy','move','mkdir','search','zip','unzip'] as $r) {
            $this->reg($ns, "/filesystem/{$r}", 'POST', "fs_{$r}");
        }
        register_rest_route($ns, '/filesystem/permissions', ['methods'=>['GET','POST'], 'callback'=>[$this,'fs_permissions'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/filesystem/disk-usage', 'GET', 'fs_disk_usage');

        // Menus
        register_rest_route($ns, '/menus', ['methods'=>['GET','POST'], 'callback'=>[$this,'menus_handler'], 'permission_callback'=>[$this,'check_admin']]);
        register_rest_route($ns, '/menus/(?P<id>\\d+)', ['methods'=>['GET','DELETE'], 'callback'=>[$this,'menu_single'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/menus/slug/(?P<slug>[\\w-]+)', 'GET', 'menu_by_slug');
        register_rest_route($ns, '/menus/(?P<id>\\d+)/items', ['methods'=>['GET','POST'], 'callback'=>[$this,'menu_items'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/menus/(?P<id>\\d+)/reorder', 'POST', 'menu_reorder');
        register_rest_route($ns, '/menu-items/(?P<id>\\d+)', ['methods'=>['POST','DELETE'], 'callback'=>[$this,'menu_item_single'], 'permission_callback'=>[$this,'check_admin']]);
        register_rest_route($ns, '/menu-locations', ['methods'=>['GET','POST'], 'callback'=>[$this,'menu_locations'], 'permission_callback'=>[$this,'check_admin']]);

        // Cache
        foreach (['flush-all','flush-object','flush-page','flush-url','flush-post','flush-transients','flush-opcache','preload'] as $r) {
            $this->reg($ns, "/cache/{$r}", 'POST', 'cache_'.str_replace('-','_',$r));
        }
        $this->reg($ns, '/cache/status', 'GET', 'cache_status');
        register_rest_route($ns, '/cache/transients/(?P<n>.+)', ['methods'=>['GET','DELETE'], 'callback'=>[$this,'cache_transient'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/cache/transients', 'POST', 'cache_set_transient');

        // Users/Roles
        register_rest_route($ns, '/users/roles', ['methods'=>['GET','POST'], 'callback'=>[$this,'roles_handler'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/users/roles/(?P<role>[\\w-]+)/capabilities', 'POST', 'role_caps');
        $this->reg($ns, '/users/roles/(?P<role>[\\w-]+)', 'DELETE', 'role_delete');
        register_rest_route($ns, '/users/(?P<id>\\d+)/meta', ['methods'=>['GET','POST'], 'callback'=>[$this,'user_meta'], 'permission_callback'=>[$this,'check_admin']]);

        // Plugins
        $this->reg($ns, '/plugins/install', 'POST', 'plugin_install');
        $this->reg($ns, '/plugins/search', 'GET', 'plugin_search');
        $this->reg($ns, '/plugins/create', 'POST', 'plugin_create');
        $this->reg($ns, '/plugins/update/(?P<slug>[\\w-]+)', 'POST', 'plugin_update_code');
        $this->reg($ns, '/plugins/code/(?P<plugin>.+)', 'GET', 'plugin_get_code');

        // Themes
        $this->reg($ns, '/themes/(?P<theme>[\\w-]+)/files', 'GET', 'theme_files');
        register_rest_route($ns, '/themes/(?P<theme>[\\w-]+)/file', ['methods'=>['GET','POST'], 'callback'=>[$this,'theme_file'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/themes/create-child', 'POST', 'theme_child');

        // Media
        $this->reg($ns, '/media/upload', 'POST', 'media_upload');

        // Site
        $this->reg($ns, '/site/info', 'GET', 'site_info');
        $this->reg($ns, '/site/health', 'GET', 'site_health');
        register_rest_route($ns, '/site/permalinks', ['methods'=>['GET','POST'], 'callback'=>[$this,'site_permalinks'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/site/export', 'POST', 'site_export');

        // Cron
        register_rest_route($ns, '/cron/events', ['methods'=>['GET','POST','DELETE'], 'callback'=>[$this,'cron_events'], 'permission_callback'=>[$this,'check_admin']]);
        $this->reg($ns, '/cron/events/(?P<hook>.+)/run', 'POST', 'cron_run');

        // Multisite
        if ( is_multisite() ) {
            register_rest_route($ns, '/multisite/sites', ['methods'=>['GET','POST'], 'callback'=>[$this,'ms_sites'], 'permission_callback'=>[$this,'check_admin']]);
            register_rest_route($ns, '/multisite/sites/(?P<id>\\d+)', ['methods'=>['GET','POST','DELETE'], 'callback'=>[$this,'ms_site'], 'permission_callback'=>[$this,'check_admin']]);
            $this->reg($ns, '/multisite/switch', 'POST', 'ms_switch');
            register_rest_route($ns, '/multisite/settings', ['methods'=>['GET','POST'], 'callback'=>[$this,'ms_settings'], 'permission_callback'=>[$this,'check_admin']]);
            $this->reg($ns, '/multisite/plugins/(?P<action>activate|deactivate)', 'POST', 'ms_plugin');
            $this->reg($ns, '/multisite/themes/enable', 'POST', 'ms_theme');
        }

        // WooCommerce Cart
        if ( class_exists('WooCommerce') ) {
            $this->reg($ns, '/cart', 'GET', 'woo_cart');
            foreach (['add','update','remove','coupon','clear'] as $r) {
                $this->reg($ns, "/cart/{$r}", 'POST', "woo_cart_{$r}");
            }
        }
    }

    // ═══ HELPERS ═══
    private function pfx($q) { global $wpdb; return str_replace('{prefix}', $wpdb->prefix, $q); }
    private function tbl($t) { global $wpdb; return (strpos($t,$wpdb->prefix)===0) ? $t : $wpdb->prefix.$t; }
    private function resolve_path($p) {
        $f = realpath(ABSPATH.ltrim($p,'/'));
        return ($f && strpos($f,realpath(ABSPATH))===0) ? $f : false;
    }

    // ═══ DATABASE ═══
    public function db_query($r) {
        global $wpdb; $p=$r->get_json_params(); $q=$this->pfx($p['query']); $type=$p['type']??'select';
        if(!empty($p['params'])) $q=$wpdb->prepare($q,...$p['params']);
        if($type==='select') { $res=$wpdb->get_results($q,ARRAY_A); return $wpdb->last_error ? new \WP_Error('db',$wpdb->last_error,['status'=>400]) : ['rows'=>count($res),'data'=>$res]; }
        $res=$wpdb->query($q); return $wpdb->last_error ? new \WP_Error('db',$wpdb->last_error,['status'=>400]) : ['affected_rows'=>$res,'insert_id'=>$wpdb->insert_id];
    }
    public function db_list_tables() { global $wpdb; return $wpdb->get_results("SELECT table_name,table_rows,ROUND(data_length/1024/1024,2) as size_mb,engine FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name",ARRAY_A); }
    public function db_describe($r) { global $wpdb; $t=$this->tbl($r['t']); return ['table'=>$t,'columns'=>$wpdb->get_results("DESCRIBE `{$t}`",ARRAY_A),'indexes'=>$wpdb->get_results("SHOW INDEX FROM `{$t}`",ARRAY_A)]; }
    public function db_create_table($r) {
        global $wpdb; $p=$r->get_json_params(); $t=$wpdb->prefix.$p['table_name']; $ch=$wpdb->get_charset_collate();
        $cols=[]; $pk=null;
        foreach($p['columns'] as $c) { $d="`{$c['name']}` {$c['type']}"; if(empty($c['nullable']))$d.=' NOT NULL'; if(isset($c['default']))$d.=" DEFAULT '{$c['default']}'"; if(!empty($c['auto_increment']))$d.=' AUTO_INCREMENT'; if(!empty($c['primary_key']))$pk=$c['name']; $cols[]=$d; }
        if($pk)$cols[]="PRIMARY KEY (`{$pk}`)";
        if(!empty($p['indexes'])) foreach($p['indexes'] as $i) { $u=!empty($i['unique'])?'UNIQUE KEY':'KEY'; $cols[]="{$u} `{$i['name']}` (`".implode('`,`',$i['columns'])."`)"; }
        $sql="CREATE TABLE `{$t}` (\n".implode(",\n",$cols)."\n) ENGINE=".($p['engine']??'InnoDB')." {$ch};";
        require_once ABSPATH.'wp-admin/includes/upgrade.php'; dbDelta($sql);
        return $wpdb->last_error ? new \WP_Error('db',$wpdb->last_error,['status'=>400]) : ['message'=>"Table {$t} created.",'sql'=>$sql];
    }
    public function db_drop_table($r) { global $wpdb; $p=$r->get_json_params(); if(empty($p['confirm'])) return new \WP_Error('confirm','Set confirm=true',['status'=>400]); $t=$this->tbl($r['t']); $wpdb->query("DROP TABLE IF EXISTS `{$t}`"); return ['message'=>"Table {$t} dropped."]; }
    public function db_alter_table($r) {
        global $wpdb; $p=$r->get_json_params(); $t=$this->tbl($r['t']); $s=[];
        if(!empty($p['add_columns'])) foreach($p['add_columns'] as $c) { $d="ADD COLUMN `{$c['name']}` {$c['type']}"; if(!empty($c['after']))$d.=" AFTER `{$c['after']}`"; $s[]=$d; }
        if(!empty($p['drop_columns'])) foreach($p['drop_columns'] as $c) $s[]="DROP COLUMN `{$c}`";
        if(!empty($p['modify_columns'])) foreach($p['modify_columns'] as $c) { $n=!empty($c['nullable'])?'NULL':'NOT NULL'; $s[]="MODIFY COLUMN `{$c['name']}` {$c['type']} {$n}"; }
        if(empty($s)) return ['message'=>'No changes.']; $sql="ALTER TABLE `{$t}` ".implode(', ',$s); $wpdb->query($sql);
        return $wpdb->last_error ? new \WP_Error('db',$wpdb->last_error,['status'=>400]) : ['message'=>'Table altered.','sql'=>$sql];
    }
    public function db_export($r) { global $wpdb; $p=$r->get_json_params(); $t=$this->tbl($r['t']); $w=!empty($p['where'])?"WHERE {$p['where']}":''; $l=intval($p['limit']??1000); return ['table'=>$t,'data'=>$wpdb->get_results("SELECT * FROM `{$t}` {$w} LIMIT {$l}",ARRAY_A)]; }
    public function db_import($r) { global $wpdb; $p=$r->get_json_params(); $t=$this->tbl($r['t']); $m=$p['mode']??'insert'; $n=0; foreach($p['data'] as $row) { $f=array_fill(0,count($row),'%s'); $m==='replace'?$wpdb->replace($t,$row,$f):$wpdb->insert($t,$row,$f); if(!$wpdb->last_error)$n++; } return ['imported'=>$n,'total'=>count($p['data'])]; }
    public function db_prefix() { global $wpdb; return ['prefix'=>$wpdb->prefix]; }
    public function db_get_option($r) { return ['name'=>$r['n'],'value'=>get_option($r['n'])]; }
    public function db_update_option($r) { $p=$r->get_json_params(); update_option($p['option_name'],$p['option_value'],$p['autoload']??'yes'); return ['message'=>"Option updated."]; }
    public function db_search_replace($r) { $p=$r->get_json_params(); return ['message'=>'Use WP-CLI: wp search-replace "'.$p['search'].'" "'.$p['replace'].'"']; }

    // ═══ FILESYSTEM ═══
    public function fs_list($r) { $p=$r->get_json_params(); $path=$this->resolve_path($p['path']??'wp-content'); if(!$path||!is_dir($path)) return new \WP_Error('path','Invalid dir',['status'=>400]); $items=[]; foreach(new \DirectoryIterator($path) as $i) { if($i->isDot())continue; $items[]=['name'=>$i->getFilename(),'type'=>$i->isDir()?'directory':'file','size'=>$i->isFile()?$i->getSize():null,'permissions'=>substr(sprintf('%o',$i->getPerms()),-4),'modified'=>date('c',$i->getMTime())]; } return ['path'=>$p['path'],'items'=>$items]; }
    public function fs_read($r) { $p=$r->get_json_params(); $f=$this->resolve_path($p['path']); if(!$f||!is_file($f)) return new \WP_Error('path','Not found',['status'=>404]); $c=file_get_contents($f); if(($p['encoding']??'utf8')==='base64')$c=base64_encode($c); return ['path'=>$p['path'],'size'=>filesize($f),'content'=>$c]; }
    public function fs_write($r) { $p=$r->get_json_params(); $f=ABSPATH.ltrim($p['path'],'/'); if($p['create_dirs']??true)wp_mkdir_p(dirname($f)); $m=($p['mode']??'write')==='append'?FILE_APPEND:0; $res=file_put_contents($f,$p['content'],$m); return $res===false?new \WP_Error('write','Failed',['status'=>500]):['path'=>$p['path'],'bytes'=>$res]; }
    public function fs_edit($r) { $p=$r->get_json_params(); $f=$this->resolve_path($p['path']); if(!$f) return new \WP_Error('path','Not found',['status'=>404]); $c=file_get_contents($f); if(!empty($p['regex'])){$c=preg_replace('/'.$p['find'].'/',  $p['replace'],$c,!empty($p['all'])?-1:1);}else{if(!empty($p['all'])){$c=str_replace($p['find'],$p['replace'],$c);}else{$pos=strpos($c,$p['find']);if($pos!==false)$c=substr_replace($c,$p['replace'],$pos,strlen($p['find']));}} file_put_contents($f,$c); return ['message'=>'File edited.']; }
    public function fs_delete($r) { $p=$r->get_json_params(); $f=$this->resolve_path($p['path']); if(!$f) return new \WP_Error('path','Not found',['status'=>404]); if(is_dir($f)){if(!empty($p['recursive'])&&!empty($p['confirm'])){$this->rmdir_r($f);}else{rmdir($f);}}else{unlink($f);} return ['message'=>'Deleted.']; }
    private function rmdir_r($d) { $i=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($d,\RecursiveDirectoryIterator::SKIP_DOTS),\RecursiveIteratorIterator::CHILD_FIRST); foreach($i as $f){$f->isDir()?rmdir($f->getRealPath()):unlink($f->getRealPath());} rmdir($d); }
    public function fs_copy($r) { $p=$r->get_json_params(); $s=$this->resolve_path($p['source']); if(!$s) return new \WP_Error('path','Not found',['status'=>404]); copy_dir($s,ABSPATH.ltrim($p['destination'],'/')); return ['message'=>'Copied.']; }
    public function fs_move($r) { $p=$r->get_json_params(); $s=$this->resolve_path($p['source']); if(!$s) return new \WP_Error('path','Not found',['status'=>404]); rename($s,ABSPATH.ltrim($p['destination'],'/')); return ['message'=>'Moved.']; }
    public function fs_mkdir($r) { $p=$r->get_json_params(); wp_mkdir_p(ABSPATH.ltrim($p['path'],'/')); return ['message'=>'Created.']; }
    public function fs_permissions($r) { if($r->get_method()==='GET'){$f=$this->resolve_path($r->get_param('path'));return ['permissions'=>substr(sprintf('%o',fileperms($f)),-4),'owner'=>fileowner($f)];} $p=$r->get_json_params();chmod($this->resolve_path($p['path']),octdec($p['permissions']));return ['message'=>'Updated.']; }
    public function fs_search($r) { $p=$r->get_json_params(); $path=$this->resolve_path($p['path']); if(!$path) return new \WP_Error('path','Not found',['status'=>400]); $res=[]; $it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path,\RecursiveDirectoryIterator::SKIP_DOTS)); $it->setMaxDepth($p['max_depth']??5); foreach($it as $f) { if($f->isDir())continue; $m=true; if(!empty($p['name_pattern']))$m=fnmatch($p['name_pattern'],$f->getFilename()); if($m&&!empty($p['content_search'])&&$f->getSize()<5000000)$m=strpos(file_get_contents($f->getRealPath()),$p['content_search'])!==false; if($m)$res[]=str_replace(ABSPATH,'',$f->getRealPath()); if(count($res)>=100)break; } return ['matches'=>count($res),'files'=>$res]; }
    public function fs_disk_usage($r) { $p=$this->resolve_path($r->get_param('path')?:'')?:ABSPATH; $s=0; foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($p)) as $f){if($f->isFile())$s+=$f->getSize();} return ['size_mb'=>round($s/1048576,2)]; }
    public function fs_zip($r) { $p=$r->get_json_params(); $z=new \ZipArchive(); $o=ABSPATH.ltrim($p['output'],'/'); $z->open($o,\ZipArchive::CREATE|\ZipArchive::OVERWRITE); foreach($p['paths'] as $rel){$f=$this->resolve_path($rel); if(is_file($f)){$z->addFile($f,basename($f));}elseif(is_dir($f)){foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($f,\RecursiveDirectoryIterator::SKIP_DOTS)) as $fi){$z->addFile($fi->getRealPath(),str_replace($f.'/','',$fi->getRealPath()));}}} $z->close(); return ['message'=>'ZIP created.','size'=>filesize($o)]; }
    public function fs_unzip($r) { $p=$r->get_json_params(); $z=$this->resolve_path($p['zip_path']); $d=ABSPATH.ltrim($p['destination'],'/'); wp_mkdir_p($d); $res=unzip_file($z,$d); return is_wp_error($res)?$res:['message'=>'Extracted.']; }

    // ═══ MENUS ═══
    public function menus_handler($r) { if($r->get_method()==='GET'){$ms=wp_get_nav_menus();$ls=get_nav_menu_locations();return array_map(function($m)use($ls){return ['id'=>$m->term_id,'name'=>$m->name,'slug'=>$m->slug,'count'=>$m->count,'locations'=>array_keys(array_filter($ls,fn($i)=>$i===$m->term_id))];},$ms);} $p=$r->get_json_params();$id=wp_create_nav_menu($p['name']);if(is_wp_error($id))return $id;if(!empty($p['location'])){$l=get_theme_mod('nav_menu_locations',[]);$l[$p['location']]=$id;set_theme_mod('nav_menu_locations',$l);}return ['id'=>$id,'message'=>'Menu created.']; }
    public function menu_single($r) { $id=intval($r['id']); if($r->get_method()==='GET'){$m=wp_get_nav_menu_object($id);return ['id'=>$m->term_id,'name'=>$m->name,'items'=>wp_get_nav_menu_items($id)];}wp_delete_nav_menu($id);return ['message'=>'Deleted.']; }
    public function menu_by_slug($r) { $m=wp_get_nav_menu_object($r['slug']); if(!$m) return new \WP_Error('404','Not found',['status'=>404]); return ['id'=>$m->term_id,'name'=>$m->name,'items'=>wp_get_nav_menu_items($m->term_id)]; }
    public function menu_items($r) { $mid=intval($r['id']); if($r->get_method()==='GET') return wp_get_nav_menu_items($mid); $p=$r->get_json_params(); $d=['menu-item-title'=>$p['title'],'menu-item-url'=>$p['url']??'','menu-item-object'=>$p['object_type']??'custom','menu-item-object-id'=>$p['object_id']??0,'menu-item-parent-id'=>$p['parent_item_id']??0,'menu-item-position'=>$p['position']??0,'menu-item-type'=>($p['object_type']??'custom')==='custom'?'custom':'post_type','menu-item-status'=>'publish','menu-item-classes'=>$p['css_classes']??'','menu-item-description'=>$p['description']??'','menu-item-target'=>$p['target']??'']; $id=wp_update_nav_menu_item($mid,0,$d); return is_wp_error($id)?$id:['id'=>$id,'message'=>'Added.']; }
    public function menu_reorder($r) { $p=$r->get_json_params(); foreach($p['item_order'] as $pos=>$id){wp_update_nav_menu_item(intval($r['id']),$id,['menu-item-position'=>$pos]);} return ['message'=>'Reordered.']; }
    public function menu_item_single($r) { $id=intval($r['id']); if($r->get_method()==='DELETE'){wp_delete_post($id,true);return ['message'=>'Deleted.'];} $p=$r->get_json_params();$d=[];if(isset($p['title']))$d['menu-item-title']=$p['title'];if(isset($p['url']))$d['menu-item-url']=$p['url'];if(isset($p['parent_item_id']))$d['menu-item-parent-id']=$p['parent_item_id'];if(isset($p['position']))$d['menu-item-position']=$p['position']; $terms=wp_get_object_terms($id,'nav_menu');$mid=!empty($terms)?$terms[0]->term_id:0; wp_update_nav_menu_item($mid,$id,$d); return ['message'=>'Updated.']; }
    public function menu_locations($r) { if($r->get_method()==='GET'){$reg=get_registered_nav_menus();$asgn=get_nav_menu_locations();$res=[];foreach($reg as $s=>$n)$res[]=['slug'=>$s,'name'=>$n,'menu_id'=>$asgn[$s]??null];return $res;} $p=$r->get_json_params();$l=get_theme_mod('nav_menu_locations',[]);$l[$p['location']]=$p['menu_id'];set_theme_mod('nav_menu_locations',$l);return ['message'=>'Assigned.']; }

    // ═══ CACHE ═══
    public function cache_flush_all() { wp_cache_flush(); if(function_exists('w3tc_flush_all'))w3tc_flush_all(); if(function_exists('rocket_clean_domain'))rocket_clean_domain(); if(class_exists('LiteSpeed_Cache_API'))\LiteSpeed_Cache_API::purge_all(); if(function_exists('opcache_reset'))opcache_reset(); return ['message'=>'All caches flushed.']; }
    public function cache_flush_object() { wp_cache_flush(); return ['message'=>'Object cache flushed.']; }
    public function cache_flush_page() { if(function_exists('wp_cache_clear_cache'))wp_cache_clear_cache(); if(function_exists('w3tc_flush_posts'))w3tc_flush_posts(); if(function_exists('rocket_clean_domain'))rocket_clean_domain(); return ['message'=>'Page cache flushed.']; }
    public function cache_flush_url($r) { $p=$r->get_json_params(); if(function_exists('rocket_clean_files'))rocket_clean_files([$p['url']]); return ['message'=>"Purged: {$p['url']}"]; }
    public function cache_flush_post($r) { $p=$r->get_json_params(); clean_post_cache($p['post_id']); return ['message'=>"Purged post {$p['post_id']}."]; }
    public function cache_flush_transients($r) { global $wpdb; $p=$r->get_json_params(); $eo=$p['expired_only']??true; if($eo){$n=$wpdb->query("DELETE a,b FROM {$wpdb->options} a INNER JOIN {$wpdb->options} b ON b.option_name=CONCAT('_transient_timeout_',SUBSTRING(a.option_name,12)) WHERE a.option_name LIKE '_transient_%' AND a.option_name NOT LIKE '_transient_timeout_%' AND b.option_value<UNIX_TIMESTAMP()");}else{$n=$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%'");} return ['deleted'=>$n]; }
    public function cache_flush_opcache() { return function_exists('opcache_reset') ? (opcache_reset()?['message'=>'OPcache reset.']:['message'=>'Reset failed.']) : ['message'=>'OPcache unavailable.']; }
    public function cache_status() { return ['object_cache'=>wp_using_ext_object_cache()?'external':'internal','page_cache'=>function_exists('rocket_clean_domain')?'WP Rocket':(function_exists('w3tc_flush_all')?'W3TC':'none detected'),'opcache'=>function_exists('opcache_get_status')?'available':'unavailable']; }
    public function cache_preload() { return ['message'=>'Use WP Rocket or LiteSpeed preload.']; }
    public function cache_transient($r) { $n=$r['n']; if($r->get_method()==='GET'){$v=get_transient($n);return ['name'=>$n,'value'=>$v,'exists'=>$v!==false];} delete_transient($n); return ['message'=>"Deleted '{$n}'."]; }
    public function cache_set_transient($r) { $p=$r->get_json_params(); set_transient($p['name'],$p['value'],$p['expiration']??0); return ['message'=>"Set '{$p['name']}'."]; }

    // ═══ ROLES ═══
    public function roles_handler($r) { if($r->get_method()==='GET'){global $wp_roles;$res=[];foreach($wp_roles->roles as $s=>$role)$res[]=['slug'=>$s,'name'=>$role['name'],'capabilities'=>$role['capabilities']];return $res;} $p=$r->get_json_params();$caps=$p['capabilities']??[];if(!empty($p['clone_from'])){$src=get_role($p['clone_from']);if($src)$caps=array_merge($src->capabilities,$caps);}add_role($p['role_slug'],$p['display_name'],$caps);return ['message'=>'Role created.']; }
    public function role_caps($r) { $p=$r->get_json_params();$role=get_role($r['role']);if(!$role) return new \WP_Error('404','Not found',['status'=>404]); if(!empty($p['add_capabilities']))foreach($p['add_capabilities'] as $c)$role->add_cap($c); if(!empty($p['remove_capabilities']))foreach($p['remove_capabilities'] as $c)$role->remove_cap($c); return ['message'=>'Capabilities updated.']; }
    public function role_delete($r) { $p=$r->get_json_params(); if(!empty($p['migrate_to']))foreach(get_users(['role'=>$r['role']]) as $u)$u->set_role($p['migrate_to']); remove_role($r['role']); return ['message'=>'Role deleted.']; }
    public function user_meta($r) { $id=intval($r['id']); if($r->get_method()==='GET') return get_user_meta($id); $p=$r->get_json_params(); update_user_meta($id,$p['key'],$p['value']); return ['message'=>'Meta updated.']; }

    // ═══ PLUGINS ═══
    public function plugin_install($r) { require_once ABSPATH.'wp-admin/includes/plugin-install.php'; require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php'; $p=$r->get_json_params(); $api=plugins_api('plugin_information',['slug'=>$p['slug']]); if(is_wp_error($api))return $api; $up=new \Plugin_Upgrader(new \Automatic_Upgrader_Skin()); $res=$up->install($api->download_link); if(is_wp_error($res))return $res; if(!empty($p['activate']))activate_plugin($p['slug'].'/'.$p['slug'].'.php'); return ['message'=>'Installed.','activated'=>!empty($p['activate'])]; }
    public function plugin_search($r) { require_once ABSPATH.'wp-admin/includes/plugin-install.php'; $res=plugins_api('query_plugins',['search'=>$r->get_param('search'),'per_page'=>intval($r->get_param('per_page')?:10)]); if(is_wp_error($res))return $res; return array_map(fn($p)=>['name'=>$p->name,'slug'=>$p->slug,'version'=>$p->version,'active_installs'=>$p->active_installs,'short_description'=>$p->short_description],$res->plugins); }
    public function plugin_create($r) { $p=$r->get_json_params(); $dir=WP_PLUGIN_DIR.'/'.$p['slug']; wp_mkdir_p($dir); file_put_contents($dir.'/'.$p['slug'].'.php',$p['code']); if(!empty($p['activate']))activate_plugin($p['slug'].'/'.$p['slug'].'.php'); return ['plugin'=>$p['slug'],'message'=>'Created.']; }
    public function plugin_update_code($r) { $p=$r->get_json_params(); $f=WP_PLUGIN_DIR."/{$r['slug']}/{$r['slug']}.php"; if(!file_exists($f)) return new \WP_Error('404','Not found',['status'=>404]); $c=file_get_contents($f); if(!empty($p['version']))$c=preg_replace('/Version:\s*[\d.]+/','Version: '.$p['version'],$c); $end=strpos($c,"if ( ! defined( 'ABSPATH' ) ) exit;"); if($end!==false){$c=substr($c,0,$end+strlen("if ( ! defined( 'ABSPATH' ) ) exit;"))."\n\n".$p['code'];} file_put_contents($f,$c); return ['message'=>'Updated.']; }
    public function plugin_get_code($r) { $f=WP_PLUGIN_DIR.'/'.urldecode($r['plugin']); return file_exists($f)?['code'=>file_get_contents($f)]:new \WP_Error('404','Not found',['status'=>404]); }

    // ═══ THEMES ═══
    public function theme_files($r) { $s=$r['theme']==='active'?get_stylesheet():$r['theme']; $d=get_theme_root().'/'.$s; if(!is_dir($d)) return new \WP_Error('404','Not found',['status'=>404]); $files=[]; foreach(new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($d,\RecursiveDirectoryIterator::SKIP_DOTS)) as $f)$files[]=str_replace($d.'/','',$f->getRealPath()); sort($files); return ['theme'=>$s,'files'=>$files]; }
    public function theme_file($r) { $s=$r['theme']==='active'?get_stylesheet():$r['theme']; $d=get_theme_root().'/'.$s; if($r->get_method()==='GET'){$f=$d.'/'.$r->get_param('path');return file_exists($f)?['content'=>file_get_contents($f)]:new \WP_Error('404','Not found',['status'=>404]);} $p=$r->get_json_params();$f=$d.'/'.$p['path'];wp_mkdir_p(dirname($f));file_put_contents($f,$p['content']);return ['message'=>'Saved.']; }
    public function theme_child($r) { $p=$r->get_json_params(); $s=$p['child_slug']??sanitize_title($p['child_name']); $d=get_theme_root().'/'.$s; wp_mkdir_p($d); file_put_contents($d.'/style.css',"/*\nTheme Name: {$p['child_name']}\nTemplate: {$p['parent_theme']}\nVersion: 1.0.0\n*/\n"); file_put_contents($d.'/functions.php',"<?php\nadd_action('wp_enqueue_scripts',function(){wp_enqueue_style('parent',get_template_directory_uri().'/style.css');});\n"); return ['slug'=>$s,'message'=>'Child theme created.']; }

    // ═══ MEDIA ═══
    public function media_upload($r) { require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; $p=$r->get_json_params(); if(!empty($p['source_url'])){$tmp=download_url($p['source_url']);if(is_wp_error($tmp))return $tmp;$id=media_handle_sideload(['name'=>$p['filename']??basename(parse_url($p['source_url'],PHP_URL_PATH)),'tmp_name'=>$tmp],0);}elseif(!empty($p['base64_data'])){$up=wp_upload_bits($p['filename']??'upload-'.time(),null,base64_decode($p['base64_data']));if($up['error'])return new \WP_Error('upload',$up['error']);$id=wp_insert_attachment(['post_title'=>$p['title']??$p['filename'],'post_mime_type'=>$up['type'],'guid'=>$up['url']],$up['file']);wp_update_attachment_metadata($id,wp_generate_attachment_metadata($id,$up['file']));}else{return new \WP_Error('no_src','Provide source_url or base64_data',['status'=>400]);} if(is_wp_error($id))return $id; if(!empty($p['alt_text']))update_post_meta($id,'_wp_attachment_image_alt',$p['alt_text']); return ['id'=>$id,'url'=>wp_get_attachment_url($id),'message'=>'Uploaded.']; }

    // ═══ SITE ═══
    public function site_info() { global $wp_version; return ['name'=>get_bloginfo('name'),'description'=>get_bloginfo('description'),'url'=>get_bloginfo('url'),'wp_version'=>$wp_version,'php_version'=>phpversion(),'active_theme'=>get_stylesheet(),'is_multisite'=>is_multisite(),'timezone'=>get_option('timezone_string'),'permalink_structure'=>get_option('permalink_structure'),'language'=>get_locale()]; }
    public function site_health() { return ['message'=>'Use wp-admin Site Health for full report.','php'=>phpversion(),'wp'=>get_bloginfo('version')]; }
    public function site_permalinks($r) { if($r->get_method()==='GET') return ['structure'=>get_option('permalink_structure'),'category_base'=>get_option('category_base'),'tag_base'=>get_option('tag_base')]; $p=$r->get_json_params(); update_option('permalink_structure',$p['structure']); flush_rewrite_rules(); return ['message'=>'Permalinks updated.']; }
    public function site_export($r) { require_once ABSPATH.'wp-admin/includes/export.php'; $p=$r->get_json_params(); $args=[]; if(!empty($p['content_type'])&&$p['content_type']!=='all')$args['content']=$p['content_type']; ob_start(); export_wp($args); $xml=ob_get_clean(); $up=wp_upload_dir(); $f=$up['basedir'].'/wp-mcp-export-'.date('Ymd-His').'.xml'; file_put_contents($f,$xml); return ['file'=>str_replace(ABSPATH,'',$f),'size'=>filesize($f)]; }

    // ═══ CRON ═══
    public function cron_events($r) { if($r->get_method()==='GET'){$crons=_get_cron_array();$events=[];foreach($crons as $ts=>$hooks)foreach($hooks as $hook=>$data)foreach($data as $ev)$events[]=['hook'=>$hook,'next_run'=>date('c',$ts),'timestamp'=>$ts,'recurrence'=>$ev['schedule']??'once','args'=>$ev['args']];usort($events,fn($a,$b)=>$a['timestamp']-$b['timestamp']);return $events;} if($r->get_method()==='POST'){$p=$r->get_json_params();$t=!empty($p['first_run'])?strtotime($p['first_run']):time();$a=$p['args']??[];in_array($p['recurrence'],['hourly','twicedaily','daily','weekly'])?wp_schedule_event($t,$p['recurrence'],$p['hook'],$a):wp_schedule_single_event($t,$p['hook'],$a);return ['message'=>'Scheduled.'];} $p=$r->get_json_params();!empty($p['timestamp'])?wp_unschedule_event($p['timestamp'],$p['hook']):wp_clear_scheduled_hook($p['hook']);return ['message'=>'Unscheduled.']; }
    public function cron_run($r) { do_action($r['hook']); return ['message'=>"Executed '{$r['hook']}'."]; }

    // ═══ MULTISITE ═══
    public function ms_sites($r) { if($r->get_method()==='GET'){$a=['number'=>100];if($r->get_param('search'))$a['search']=$r->get_param('search');return array_map(fn($s)=>['id'=>$s->blog_id,'domain'=>$s->domain,'path'=>$s->path,'registered'=>$s->registered,'public'=>$s->public,'archived'=>$s->archived,'deleted'=>$s->deleted],get_sites($a));} $p=$r->get_json_params();$id=wpmu_create_blog($p['domain'],$p['path']??'/',$p['title'],$p['admin_user_id']??get_current_user_id());return is_wp_error($id)?$id:['site_id'=>$id,'message'=>'Created.']; }
    public function ms_site($r) { $id=intval($r['id']); if($r->get_method()==='GET'){$s=get_site($id);switch_to_blog($id);$d=['id'=>$id,'domain'=>$s->domain,'path'=>$s->path,'title'=>get_bloginfo('name')];restore_current_blog();return $d;} if($r->get_method()==='DELETE'){$p=$r->get_json_params();if(empty($p['confirm']))return new \WP_Error('confirm','Confirm',['status'=>400]);wpmu_delete_blog($id,!empty($p['drop_tables']));return ['message'=>'Deleted.'];} $p=$r->get_json_params();$u=[];foreach(['domain','path','public','archived','spam','deleted','mature'] as $f)if(isset($p[$f]))$u[$f]=$p[$f];if(!empty($u))update_blog_details($id,$u);if(!empty($p['title'])){switch_to_blog($id);update_option('blogname',$p['title']);restore_current_blog();}return ['message'=>'Updated.']; }
    public function ms_switch($r) { $p=$r->get_json_params(); switch_to_blog($p['site_id']); return ['message'=>"Switched to {$p['site_id']}.",'name'=>get_bloginfo('name')]; }
    public function ms_settings($r) { if($r->get_method()==='GET') return ['registration'=>get_site_option('registration'),'upload_space'=>get_site_option('blog_upload_space'),'fileupload_maxk'=>get_site_option('fileupload_maxk')]; $p=$r->get_json_params(); foreach(['registration','upload_space','fileupload_maxk'] as $k)if(isset($p[$k]))update_site_option($k==='upload_space'?'blog_upload_space':$k,$p[$k]); return ['message'=>'Updated.']; }
    public function ms_plugin($r) { $p=$r->get_json_params(); $active=get_site_option('active_sitewide_plugins',[]); if($r['action']==='activate'){$active[$p['plugin']]=time();}else{unset($active[$p['plugin']]);} update_site_option('active_sitewide_plugins',$active); return ['message'=>"Plugin {$r['action']}d network-wide."]; }
    public function ms_theme($r) { $p=$r->get_json_params(); $a=get_site_option('allowedthemes',[]); $a[$p['theme']]=true; update_site_option('allowedthemes',$a); return ['message'=>"Theme enabled."]; }

    // ═══ WOOCOMMERCE CART ═══
    public function woo_cart($r) { if(!function_exists('WC')) return new \WP_Error('no_woo','WooCommerce not active',['status'=>400]); wc_load_cart(); $c=WC()->cart; $items=[]; foreach($c->get_cart() as $k=>$i){$p=$i['data'];$items[]=['key'=>$k,'product_id'=>$i['product_id'],'variation_id'=>$i['variation_id'],'name'=>$p->get_name(),'quantity'=>$i['quantity'],'price'=>$p->get_price(),'total'=>$i['line_total']];} return ['items'=>$items,'item_count'=>$c->get_cart_contents_count(),'subtotal'=>$c->get_subtotal(),'total'=>$c->get_total('edit'),'coupons'=>array_map(fn($c)=>$c->get_code(),$c->get_coupons())]; }
    public function woo_cart_add($r) { wc_load_cart(); $p=$r->get_json_params(); $k=WC()->cart->add_to_cart($p['product_id'],$p['quantity']??1,$p['variation_id']??0,$p['variation']??[]); return $k?['item_key'=>$k,'message'=>'Added.']:new \WP_Error('cart','Failed',['status'=>400]); }
    public function woo_cart_update($r) { wc_load_cart(); $p=$r->get_json_params(); WC()->cart->set_quantity($p['item_key'],$p['quantity']); return ['message'=>'Updated.']; }
    public function woo_cart_remove($r) { wc_load_cart(); $p=$r->get_json_params(); WC()->cart->remove_cart_item($p['item_key']); return ['message'=>'Removed.']; }
    public function woo_cart_coupon($r) { wc_load_cart(); $p=$r->get_json_params(); return WC()->cart->apply_coupon($p['coupon_code'])?['message'=>'Applied.']:new \WP_Error('coupon','Failed',['status'=>400]); }
    public function woo_cart_clear() { wc_load_cart(); WC()->cart->empty_cart(); return ['message'=>'Cleared.']; }
}

new WP_MCP_Companion();
