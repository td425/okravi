/**
 * SECTION 4: Plugin Management & Custom Plugin Creation
 * List, install, activate, deactivate, delete plugins.
 * Generate and deploy custom plugins directly to the site.
 */

export const pluginTools = [
  {
    name: "list_plugins",
    description: "List all installed plugins with status, version, author, update availability.",
    inputSchema: {
      type: "object",
      properties: {
        status: { type: "string", description: "Filter: active, inactive, network-active" },
        search: { type: "string", description: "Search by name" },
      },
    },
  },
  {
    name: "get_plugin",
    description: "Get detailed info about a specific plugin by its plugin file path (e.g., 'akismet/akismet.php').",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path (e.g., 'woocommerce/woocommerce.php')" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "activate_plugin",
    description: "Activate an installed plugin.",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path" },
        network_wide: { type: "boolean", description: "Activate network-wide (multisite)" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "deactivate_plugin",
    description: "Deactivate a plugin.",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "delete_plugin",
    description: "Delete a plugin (must be deactivated first).",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path" },
      },
      required: ["plugin"],
    },
  },
  {
    name: "install_plugin",
    description: "Install a plugin from the WordPress.org repository by slug.",
    inputSchema: {
      type: "object",
      properties: {
        slug: { type: "string", description: "WordPress.org plugin slug (e.g., 'woocommerce')" },
        activate: { type: "boolean", description: "Activate after install (default: false)" },
      },
      required: ["slug"],
    },
  },
  {
    name: "search_plugins_repo",
    description: "Search the WordPress.org plugin repository.",
    inputSchema: {
      type: "object",
      properties: {
        search: { type: "string", description: "Search term" },
        per_page: { type: "number", description: "Results to return (default 10)" },
      },
      required: ["search"],
    },
  },
  {
    name: "create_custom_plugin",
    description: "Generate and deploy a custom WordPress plugin. Provide the plugin name, description, and PHP code. The plugin file will be created on the server and can be activated immediately.",
    inputSchema: {
      type: "object",
      properties: {
        name: { type: "string", description: "Plugin name (e.g., 'My Custom Features')" },
        slug: { type: "string", description: "Plugin folder/file slug (e.g., 'my-custom-features')" },
        description: { type: "string", description: "Plugin description" },
        version: { type: "string", description: "Version (default: 1.0.0)" },
        author: { type: "string", description: "Author name" },
        php_code: { type: "string", description: "The PHP code for the plugin (without opening <?php tag or plugin header — those are auto-generated)" },
        activate: { type: "boolean", description: "Activate after creation (default: false)" },
        hooks: {
          type: "array",
          description: "WordPress hooks to register. Each item: { hook, callback, priority, type: 'action'|'filter' }",
          items: {
            type: "object",
            properties: {
              hook: { type: "string" },
              callback: { type: "string" },
              priority: { type: "number" },
              type: { type: "string" },
            },
          },
        },
      },
      required: ["name", "slug", "php_code"],
    },
  },
  {
    name: "update_custom_plugin",
    description: "Update the PHP code of a custom plugin that was previously created via this MCP server.",
    inputSchema: {
      type: "object",
      properties: {
        slug: { type: "string", description: "Plugin slug" },
        php_code: { type: "string", description: "Updated PHP code (without header)" },
        version: { type: "string", description: "New version number" },
      },
      required: ["slug", "php_code"],
    },
  },
  {
    name: "get_plugin_code",
    description: "Read the source code of an installed plugin file.",
    inputSchema: {
      type: "object",
      properties: {
        plugin: { type: "string", description: "Plugin file path" },
      },
      required: ["plugin"],
    },
  },
];

export async function handlePluginTools(name, args, wpFetch, wpCustomFetch) {
  switch (name) {
    case "list_plugins": {
      const params = new URLSearchParams();
      if (args.status) params.set("status", args.status);
      if (args.search) params.set("search", args.search);
      const plugins = await wpFetch(`/plugins?${params}`);
      return plugins.map((p) => ({
        plugin: p.plugin,
        name: p.name,
        status: p.status,
        version: p.version,
        author: p.author,
        description: p.description?.raw || p.description,
        requires_wp: p.requires_wp,
        requires_php: p.requires_php,
        network_only: p.network_only,
      }));
    }

    case "get_plugin": {
      const encoded = encodeURIComponent(args.plugin);
      const plugin = await wpFetch(`/plugins/${encoded}`);
      return {
        plugin: plugin.plugin,
        name: plugin.name,
        status: plugin.status,
        version: plugin.version,
        author: plugin.author,
        description: plugin.description?.raw || plugin.description,
        plugin_uri: plugin.plugin_uri,
        requires_wp: plugin.requires_wp,
        requires_php: plugin.requires_php,
      };
    }

    case "activate_plugin": {
      const encoded = encodeURIComponent(args.plugin);
      const plugin = await wpFetch(`/plugins/${encoded}`, {
        method: "POST",
        body: JSON.stringify({ status: "active" }),
      });
      return { plugin: plugin.plugin, status: plugin.status, message: `Plugin "${plugin.name}" activated.` };
    }

    case "deactivate_plugin": {
      const encoded = encodeURIComponent(args.plugin);
      const plugin = await wpFetch(`/plugins/${encoded}`, {
        method: "POST",
        body: JSON.stringify({ status: "inactive" }),
      });
      return { plugin: plugin.plugin, status: plugin.status, message: `Plugin "${plugin.name}" deactivated.` };
    }

    case "delete_plugin": {
      const encoded = encodeURIComponent(args.plugin);
      await wpFetch(`/plugins/${encoded}`, { method: "DELETE" });
      return { message: `Plugin "${args.plugin}" deleted.` };
    }

    case "install_plugin": {
      const result = await wpCustomFetch("/wp-mcp/v1/plugins/install", {
        method: "POST",
        body: JSON.stringify({ slug: args.slug, activate: args.activate || false }),
      });
      return result;
    }

    case "search_plugins_repo": {
      const result = await wpCustomFetch(`/wp-mcp/v1/plugins/search?search=${encodeURIComponent(args.search)}&per_page=${args.per_page || 10}`);
      return result;
    }

    case "create_custom_plugin": {
      const version = args.version || "1.0.0";
      const author = args.author || "WP-MCP Generator";

      let pluginCode = `<?php
/**
 * Plugin Name: ${args.name}
 * Description: ${args.description || "Custom plugin generated via WordPress MCP Server."}
 * Version: ${version}
 * Author: ${author}
 * Text Domain: ${args.slug}
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

`;
      // Add hook registrations if provided
      if (args.hooks && args.hooks.length > 0) {
        for (const hook of args.hooks) {
          const type = hook.type === "filter" ? "add_filter" : "add_action";
          const priority = hook.priority || 10;
          pluginCode += `${type}( '${hook.hook}', '${hook.callback}', ${priority} );\n`;
        }
        pluginCode += "\n";
      }

      pluginCode += args.php_code;

      const result = await wpCustomFetch("/wp-mcp/v1/plugins/create", {
        method: "POST",
        body: JSON.stringify({
          slug: args.slug,
          code: pluginCode,
          activate: args.activate || false,
        }),
      });

      return {
        ...result,
        message: `Custom plugin "${args.name}" created${args.activate ? " and activated" : ""}.`,
      };
    }

    case "update_custom_plugin": {
      const result = await wpCustomFetch(`/wp-mcp/v1/plugins/update/${args.slug}`, {
        method: "POST",
        body: JSON.stringify({
          code: args.php_code,
          version: args.version,
        }),
      });
      return { ...result, message: `Plugin "${args.slug}" code updated.` };
    }

    case "get_plugin_code": {
      const result = await wpCustomFetch(`/wp-mcp/v1/plugins/code/${encodeURIComponent(args.plugin)}`);
      return result;
    }

    default:
      return null;
  }
}
