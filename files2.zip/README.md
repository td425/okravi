# WordPress Ultimate MCP Server

> **187 tools** across **11 sections** — full WordPress control via Claude and Model Context Protocol.

---

## 📦 What's Included

```
wordpress-ultimate-mcp/
├── server.js                          # Main MCP server (imports all sections)
├── package.json
├── mcp-config-example.json            # Claude Desktop / Claude Code config
├── sections/
│   ├── 01-pages.js                    # Pages & Content (9 tools)
│   ├── 02-posts.js                    # Posts & Custom Post Types (19 tools)
│   ├── 03-menus.js                    # Menus & Mega Menus (11 tools)
│   ├── 04-plugins.js                  # Plugin Management & Creation (11 tools)
│   ├── 05-woocommerce.js             # Full WooCommerce Integration (37 tools)
│   ├── 06-database.js                # Direct Database Access (13 tools)
│   ├── 07-multisite.js               # Multisite Network Management (11 tools)
│   ├── 08-users.js                   # Users, Roles & Capabilities (13 tools)
│   ├── 09-cache.js                   # Cache Control (12 tools)
│   ├── 10-files.js                   # File System, Media & Themes (24 tools)
│   └── 11-utilities.js               # Settings, Comments, Widgets, Cron (27 tools)
└── companion-plugin/
    └── wp-mcp-companion.php           # WordPress plugin (required for advanced features)
```

---

## 🚀 Quick Setup (5 minutes)

### Step 1: Install the Companion Plugin

Upload `companion-plugin/wp-mcp-companion.php` to your WordPress site:

```
wp-content/plugins/wp-mcp-companion/wp-mcp-companion.php
```

Activate it in **wp-admin → Plugins**. This plugin powers database, filesystem, menu, cache, cron, and multisite operations.

### Step 2: Create WordPress Credentials

**Application Password:**
1. Go to **wp-admin → Users → Profile**
2. Scroll to **Application Passwords**
3. Name it `claude-mcp`, click **Add New**
4. Copy the password immediately

**WooCommerce API Keys** (if using WooCommerce):
1. Go to **WooCommerce → Settings → Advanced → REST API**
2. Click **Add Key**, set permissions to **Read/Write**
3. Copy the Consumer Key and Consumer Secret

### Step 3: Install & Configure

```bash
cd wordpress-ultimate-mcp
npm install
```

### Step 4: Connect to Claude

Edit `mcp-config-example.json` with your real values, then:

**Claude Desktop App:**
Copy the config into `claude_desktop_config.json`:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

**Claude Code (CLI):**
Save as `.mcp.json` in your project root, then run `claude`.

### Step 5: Test

```
> "List all pages on my site"
> "Show me WooCommerce orders from this week"
> "What tables are in my database?"
> "Flush all caches"
```

---

## 🛠️ Tool Reference by Section

### Section 1: Pages & Content (9 tools)
`list_pages` · `get_page` · `create_page` · `update_page` · `delete_page` · `list_page_revisions` · `restore_page_revision` · `duplicate_page` · `bulk_update_pages`

### Section 2: Posts & Custom Post Types (19 tools)
`list_posts` · `get_post` · `create_post` · `update_post` · `delete_post` · `list_post_revisions` · `bulk_update_posts` · `list_post_types` · `list_custom_posts` · `create_custom_post` · `update_custom_post` · `list_categories` · `create_category` · `update_category` · `delete_category` · `list_tags` · `create_tag` · `list_taxonomies`

### Section 3: Menus & Mega Menus (11 tools)
`list_menus` · `get_menu` · `create_menu` · `delete_menu` · `add_menu_item` · `update_menu_item` · `delete_menu_item` · `reorder_menu_items` · `list_menu_locations` · `assign_menu_location` · `create_mega_menu`

### Section 4: Plugin Management (11 tools)
`list_plugins` · `get_plugin` · `activate_plugin` · `deactivate_plugin` · `delete_plugin` · `install_plugin` · `search_plugins_repo` · `create_custom_plugin` · `update_custom_plugin` · `get_plugin_code`

### Section 5: WooCommerce (37 tools)
**Products:** `woo_list_products` · `woo_get_product` · `woo_create_product` · `woo_update_product` · `woo_delete_product` · `woo_bulk_update_products`
**Variations:** `woo_list_variations` · `woo_create_variation` · `woo_update_variation`
**Categories:** `woo_list_product_categories` · `woo_create_product_category`
**Orders:** `woo_list_orders` · `woo_get_order` · `woo_create_order` · `woo_update_order` · `woo_add_order_note` · `woo_create_refund`
**Cart:** `woo_get_cart` · `woo_add_to_cart` · `woo_update_cart_item` · `woo_remove_cart_item` · `woo_apply_coupon` · `woo_clear_cart`
**Coupons:** `woo_list_coupons` · `woo_create_coupon`
**Customers:** `woo_list_customers` · `woo_get_customer`
**Shipping/Tax:** `woo_list_shipping_zones` · `woo_list_tax_classes`
**Reports:** `woo_sales_report` · `woo_top_sellers`
**Settings:** `woo_get_settings` · `woo_update_setting`

### Section 6: Database Access (13 tools)
`db_query` · `db_execute` · `db_list_tables` · `db_describe_table` · `db_create_table` · `db_drop_table` · `db_alter_table` · `db_export_table` · `db_import_data` · `db_get_table_prefix` · `db_get_option` · `db_update_option` · `db_search_replace`

### Section 7: Multisite (11 tools)
`ms_list_sites` · `ms_get_site` · `ms_create_site` · `ms_update_site` · `ms_delete_site` · `ms_switch_to_site` · `ms_network_activate_plugin` · `ms_network_deactivate_plugin` · `ms_network_enable_theme` · `ms_get_network_settings` · `ms_update_network_settings`

### Section 8: User Management (13 tools)
`list_users` · `get_user` · `create_user` · `update_user` · `delete_user` · `list_roles` · `create_role` · `update_role_capabilities` · `delete_role` · `bulk_update_users` · `get_current_user` · `get_user_meta` · `update_user_meta`

### Section 9: Caching (12 tools)
`cache_flush_all` · `cache_flush_object` · `cache_flush_page` · `cache_flush_url` · `cache_flush_post` · `cache_flush_transients` · `cache_flush_opcache` · `cache_get_status` · `cache_preload` · `cache_get_transient` · `cache_set_transient` · `cache_delete_transient`

### Section 10: Files, Media & Themes (24 tools)
**Filesystem:** `fs_list_directory` · `fs_read_file` · `fs_write_file` · `fs_edit_file` · `fs_delete_file` · `fs_copy_file` · `fs_move_file` · `fs_create_directory` · `fs_get_permissions` · `fs_set_permissions` · `fs_search_files` · `fs_get_disk_usage` · `fs_zip_files` · `fs_unzip`
**Media:** `media_list` · `media_get` · `media_upload` · `media_update` · `media_delete`
**Themes:** `theme_list` · `theme_get_active` · `theme_activate` · `theme_get_file` · `theme_edit_file` · `theme_create_child`

### Section 11: Settings & Utilities (27 tools)
**Site:** `get_site_info` · `get_site_settings` · `update_site_settings` · `get_permalink_structure` · `update_permalink_structure`
**Comments:** `list_comments` · `get_comment` · `create_comment` · `update_comment` · `delete_comment` · `bulk_moderate_comments`
**Widgets:** `list_sidebars` · `list_widgets` · `add_widget` · `update_widget` · `delete_widget`
**Cron:** `list_cron_events` · `create_cron_event` · `delete_cron_event` · `run_cron_event`
**Health:** `get_site_health`
**Export:** `export_content`

---

## 🔒 Security

- **All endpoints require administrator authentication** — the companion plugin checks `manage_options` capability on every request.
- **Use dedicated credentials** — create a WordPress user specifically for MCP with only the roles needed.
- **Never commit credentials** — add `.mcp.json` to `.gitignore`.
- **Use HTTPS** — always connect over SSL.
- **Database tools are powerful** — `db_execute` runs raw SQL. Consider removing it in production or adding query allowlists.
- **Application Passwords can be revoked** at any time from wp-admin.

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| `401 Unauthorized` | Check username and app password. No extra spaces. |
| `403 Forbidden` | User needs Administrator role. |
| `rest_no_route` | Companion plugin not activated, or REST API blocked by a security plugin. |
| WooCommerce tools fail | Install WooCommerce, or provide API keys in env vars. |
| Multisite tools missing | Only available on multisite installs (`is_multisite()` must return true). |
| `ECONNREFUSED` | WordPress site not reachable. Check URL, firewall, VPN. |
| Menu tools fail | Activate companion plugin. Classic menus need the plugin; FSE themes use navigation blocks as fallback. |

---

## 📄 License

MIT
