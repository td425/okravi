#!/usr/bin/env node

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║          WordPress Ultimate MCP Server v1.0.0                   ║
 * ║                                                                  ║
 * ║  Full WordPress control via Model Context Protocol              ║
 * ║                                                                  ║
 * ║  SECTIONS:                                                       ║
 * ║   01. Pages & Content Management                                ║
 * ║   02. Posts & Custom Post Types                                 ║
 * ║   03. Menus & Mega Menus                                       ║
 * ║   04. Plugin Management & Custom Plugin Creation                ║
 * ║   05. WooCommerce (Products, Orders, Cart, Coupons, Reports)   ║
 * ║   06. Database Access & Control                                 ║
 * ║   07. Multisite Management                                      ║
 * ║   08. User Management & Roles                                   ║
 * ║   09. Caching Control                                           ║
 * ║   10. File Management, Media & Themes                          ║
 * ║   11. Site Settings, Comments, Widgets, Cron & Utilities       ║
 * ║                                                                  ║
 * ║  Requires: WP-MCP Companion Plugin for advanced features       ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * Environment variables:
 *   WP_URL              - WordPress site URL (e.g., https://yoursite.com)
 *   WP_USER             - WordPress admin username
 *   WP_APP_PASSWORD     - Application password
 *   WP_WOO_CONSUMER_KEY - WooCommerce REST API consumer key (optional)
 *   WP_WOO_CONSUMER_SECRET - WooCommerce REST API consumer secret (optional)
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";

// ── Import all sections ──
import { pageTools, handlePageTools } from "./sections/01-pages.js";
import { postTools, handlePostTools } from "./sections/02-posts.js";
import { menuTools, handleMenuTools } from "./sections/03-menus.js";
import { pluginTools, handlePluginTools } from "./sections/04-plugins.js";
import { wooTools, handleWooTools } from "./sections/05-woocommerce.js";
import { dbTools, handleDbTools } from "./sections/06-database.js";
import { multisiteTools, handleMultisiteTools } from "./sections/07-multisite.js";
import { userTools, handleUserTools } from "./sections/08-users.js";
import { cacheTools, handleCacheTools } from "./sections/09-cache.js";
import { fileTools, handleFileTools } from "./sections/10-files.js";
import { utilityTools, handleUtilityTools } from "./sections/11-utilities.js";

// ═══════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════

const WP_URL = process.env.WP_URL?.replace(/\/+$/, "");
const WP_USER = process.env.WP_USER;
const WP_APP_PASSWORD = process.env.WP_APP_PASSWORD;
const WOO_CK = process.env.WP_WOO_CONSUMER_KEY;
const WOO_CS = process.env.WP_WOO_CONSUMER_SECRET;

if (!WP_URL || !WP_USER || !WP_APP_PASSWORD) {
  console.error("❌ Missing required environment variables:");
  console.error("   WP_URL, WP_USER, WP_APP_PASSWORD");
  console.error("");
  console.error("Example:");
  console.error('   WP_URL="https://yoursite.com" WP_USER="admin" WP_APP_PASSWORD="xxxx xxxx" node server.js');
  process.exit(1);
}

const AUTH_HEADER =
  "Basic " + Buffer.from(`${WP_USER}:${WP_APP_PASSWORD}`).toString("base64");

// ═══════════════════════════════════════════════════════════════════
// API HELPERS
// ═══════════════════════════════════════════════════════════════════

/**
 * WordPress REST API v2 — /wp-json/wp/v2/...
 */
async function wpFetch(endpoint, options = {}) {
  const url = `${WP_URL}/wp-json/wp/v2${endpoint}`;
  const resp = await fetch(url, {
    ...options,
    headers: {
      Authorization: AUTH_HEADER,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });
  if (!resp.ok) {
    const body = await resp.text();
    throw new Error(`WP API ${resp.status} [${endpoint}]: ${body.substring(0, 500)}`);
  }
  return resp.json();
}

/**
 * WP-MCP Companion Plugin API — /wp-json/wp-mcp/v1/...
 * Used for advanced features (DB, filesystem, menus, cache, etc.)
 */
async function wpCustomFetch(endpoint, options = {}) {
  const url = `${WP_URL}/wp-json${endpoint}`;
  const resp = await fetch(url, {
    ...options,
    headers: {
      Authorization: AUTH_HEADER,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });
  if (!resp.ok) {
    const body = await resp.text();
    throw new Error(`WP-MCP Plugin API ${resp.status} [${endpoint}]: ${body.substring(0, 500)}`);
  }
  return resp.json();
}

/**
 * WooCommerce REST API v3 — /wp-json/wc/v3/...
 * Uses either consumer key/secret or app password auth
 */
async function wooFetch(endpoint, options = {}) {
  let url = `${WP_URL}/wp-json/wc/v3${endpoint}`;

  const headers = { "Content-Type": "application/json", ...options.headers };

  // Use WooCommerce API keys if available, otherwise fall back to app password
  if (WOO_CK && WOO_CS) {
    const sep = url.includes("?") ? "&" : "?";
    url += `${sep}consumer_key=${WOO_CK}&consumer_secret=${WOO_CS}`;
  } else {
    headers.Authorization = AUTH_HEADER;
  }

  const resp = await fetch(url, { ...options, headers });
  if (!resp.ok) {
    const body = await resp.text();
    throw new Error(`WooCommerce API ${resp.status} [${endpoint}]: ${body.substring(0, 500)}`);
  }
  return resp.json();
}

// ═══════════════════════════════════════════════════════════════════
// AGGREGATE ALL TOOLS
// ═══════════════════════════════════════════════════════════════════

const ALL_TOOLS = [
  ...pageTools,         // 9 tools
  ...postTools,         // 19 tools
  ...menuTools,         // 11 tools
  ...pluginTools,       // 11 tools
  ...wooTools,          // 37 tools
  ...dbTools,           // 13 tools
  ...multisiteTools,    // 11 tools
  ...userTools,         // 13 tools
  ...cacheTools,        // 12 tools
  ...fileTools,         // 24 tools
  ...utilityTools,      // 27 tools
];

console.error(`📦 Loaded ${ALL_TOOLS.length} tools across 11 sections`);

// ═══════════════════════════════════════════════════════════════════
// TOOL ROUTING
// ═══════════════════════════════════════════════════════════════════

// Build name → section mapping for O(1) dispatch
const toolSectionMap = new Map();
pageTools.forEach((t) => toolSectionMap.set(t.name, "pages"));
postTools.forEach((t) => toolSectionMap.set(t.name, "posts"));
menuTools.forEach((t) => toolSectionMap.set(t.name, "menus"));
pluginTools.forEach((t) => toolSectionMap.set(t.name, "plugins"));
wooTools.forEach((t) => toolSectionMap.set(t.name, "woo"));
dbTools.forEach((t) => toolSectionMap.set(t.name, "db"));
multisiteTools.forEach((t) => toolSectionMap.set(t.name, "multisite"));
userTools.forEach((t) => toolSectionMap.set(t.name, "users"));
cacheTools.forEach((t) => toolSectionMap.set(t.name, "cache"));
fileTools.forEach((t) => toolSectionMap.set(t.name, "files"));
utilityTools.forEach((t) => toolSectionMap.set(t.name, "utilities"));

async function routeTool(name, args) {
  const section = toolSectionMap.get(name);
  if (!section) throw new Error(`Unknown tool: ${name}`);

  switch (section) {
    case "pages":
      return await handlePageTools(name, args, wpFetch);
    case "posts":
      return await handlePostTools(name, args, wpFetch, wpCustomFetch);
    case "menus":
      return await handleMenuTools(name, args, wpFetch, wpCustomFetch);
    case "plugins":
      return await handlePluginTools(name, args, wpFetch, wpCustomFetch);
    case "woo":
      return await handleWooTools(name, args, wooFetch, wpCustomFetch);
    case "db":
      return await handleDbTools(name, args, wpCustomFetch);
    case "multisite":
      return await handleMultisiteTools(name, args, wpCustomFetch);
    case "users":
      return await handleUserTools(name, args, wpFetch, wpCustomFetch);
    case "cache":
      return await handleCacheTools(name, args, wpCustomFetch);
    case "files":
      return await handleFileTools(name, args, wpFetch, wpCustomFetch);
    case "utilities":
      return await handleUtilityTools(name, args, wpFetch, wpCustomFetch);
    default:
      throw new Error(`No handler for section: ${section}`);
  }
}

// ═══════════════════════════════════════════════════════════════════
// MCP SERVER
// ═══════════════════════════════════════════════════════════════════

const server = new Server(
  {
    name: "wordpress-ultimate-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: { tools: {} },
  }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: ALL_TOOLS,
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  const startTime = Date.now();

  try {
    const result = await routeTool(name, args ?? {});
    const elapsed = Date.now() - startTime;
    console.error(`✅ ${name} (${elapsed}ms)`);
    return {
      content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
    };
  } catch (error) {
    const elapsed = Date.now() - startTime;
    console.error(`❌ ${name} (${elapsed}ms): ${error.message}`);
    return {
      content: [{ type: "text", text: `Error: ${error.message}` }],
      isError: true,
    };
  }
});

// ═══════════════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════════════

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("🚀 WordPress Ultimate MCP Server running on stdio");
  console.error(`🌐 Connected to: ${WP_URL}`);
  console.error(`👤 User: ${WP_USER}`);
  console.error(`🛒 WooCommerce: ${WOO_CK ? "API keys configured" : "Using app password auth"}`);
}

main().catch((err) => {
  console.error("💀 Fatal error:", err);
  process.exit(1);
});
